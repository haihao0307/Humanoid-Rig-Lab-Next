const fs=require('node:fs'),crypto=require('node:crypto'),{execFileSync}=require('node:child_process');
const [metaFile,local,backup]=process.argv.slice(2),m=JSON.parse(fs.readFileSync(metaFile,'utf8'));
const git=(...args)=>execFileSync('git',args,{encoding:'utf8'}).trim();
if(git('rev-parse',local+':')!==m.tree.sha||git('rev-parse','HEAD')!==local)throw Error('Local tree or HEAD mismatch');
if(m.verification.signature)throw Error('Signed commit import unsupported');
const offsets=['+0000','-0000'];for(let min=-720;min<=840;min+=15){const a=Math.abs(min);offsets.push((min<0?'-':'+')+String(Math.floor(a/60)).padStart(2,'0')+String(a%60).padStart(2,'0'));}
let raw;outer:for(const a of offsets)for(const c of offsets)for(const tail of ['','\n','\n\n','\r\n']){const text=`tree ${m.tree.sha}\n${m.parents.map(p=>'parent '+p.sha+'\n').join('')}author ${m.author.name} <${m.author.email}> ${Date.parse(m.author.date)/1000} ${a}\ncommitter ${m.committer.name} <${m.committer.email}> ${Date.parse(m.committer.date)/1000} ${c}\n\n${m.message}${tail}`,b=Buffer.from(text);if(crypto.createHash('sha1').update('commit '+b.length+'\0').update(b).digest('hex')===m.sha){raw=b;break outer;}}
if(!raw)throw Error('Cannot recreate exact GitHub commit object');
const imported=execFileSync('git',['hash-object','-t','commit','-w','--stdin'],{input:raw,encoding:'utf8'}).trim();if(imported!==m.sha)throw Error('Commit hash mismatch');
git('update-ref',backup,local,'0000000000000000000000000000000000000000');
git('update-ref','HEAD',m.sha,local);git('update-ref','refs/remotes/github/work/local-human-r006-binding-20260930',m.sha);
console.log(JSON.stringify({head:m.sha,tree:m.tree.sha,backup}));
