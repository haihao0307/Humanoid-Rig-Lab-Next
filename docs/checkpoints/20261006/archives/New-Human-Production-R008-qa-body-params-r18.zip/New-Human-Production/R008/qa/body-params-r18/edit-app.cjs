const fs=require('node:fs'),path=require('node:path');const file=path.resolve(__dirname,'../../app.mjs');let s=fs.readFileSync(file,'utf8');
const replace=(a,b)=>{if(!s.includes(a))throw Error('Missing anchor '+a.slice(0,50));s=s.replace(a,b);};
replace("import {createSkinWorkbench} from './SkinWorkbench.mjs';","import {createSkinWorkbench} from './SkinWorkbench.mjs';\nimport {createBodyWorkbench} from './BodyWorkbench.mjs';");
replace('window.HumanSkin=skinWorkbench;','window.HumanSkin=skinWorkbench;\nconst bodyWorkbench=createBodyWorkbench({apply:applyBodyRecipe,getReport:()=>subject?.body.report});window.HumanBody=bodyWorkbench;');
replace('controller.y+1.05,controller.z','controller.y+1.05*actor.scale.y,controller.z');
replace('new THREE.Vector3(side*.25,1.30,0).applyQuaternion(actor.quaternion)','new THREE.Vector3(side*.25,1.30,0).multiplyScalar(actor.scale.y).applyQuaternion(actor.quaternion)');
replace('new THREE.Vector3(side*.10,.025,.88).applyQuaternion(actor.quaternion)','new THREE.Vector3(side*.10,.025,.88).multiplyScalar(actor.scale.y).applyQuaternion(actor.quaternion)');
replace('new THREE.Vector3(0,.035,.015).applyQuaternion(actor.quaternion)','new THREE.Vector3(0,.035,.015).multiplyScalar(actor.scale.y).applyQuaternion(actor.quaternion)');
replace('new THREE.Vector3(0,.015,.58).applyQuaternion(actor.quaternion)','new THREE.Vector3(0,.015,.58).multiplyScalar(actor.scale.y).applyQuaternion(actor.quaternion)');
replace('world.shadow.scale.setScalar(1+Math.max(0,controller.y-ground)*.18)','world.shadow.scale.setScalar(actor.scale.y*(1+Math.max(0,controller.y-ground)*.18))');
replace('actor.add(subject.root);subject.setInPlace(true);','actor.add(subject.root);bodyWorkbench.bind();subject.setInPlace(true);');
replace('function disposeSubject(){',`function applyBodyRecipe(recipe){
 if(!subject)return;const previousPaused=paused,previousScale=actor.scale.y,snapshot=view.snapshot();paused=true;controller.clearInput();
 try{subject.body.set(recipe);const metrics=subject.body.report;actor.scale.setScalar(metrics.scale);controller.setBodyMetrics(metrics);actor.updateMatrixWorld(true);subject.finishPose();
  if(metrics.scale!==previousScale){const ratio=metrics.scale/previousScale,p=new THREE.Vector3().fromArray(snapshot.position).sub(actor.position).multiplyScalar(ratio).add(actor.position),t=new THREE.Vector3().fromArray(snapshot.target).sub(actor.position).multiplyScalar(ratio).add(actor.position);view.frame(t,p,cameraAnchor());}
 }finally{paused=previousPaused;lastTime=performance.now();}
 return subject.body.report;
}
function disposeSubject(){`);
fs.writeFileSync(file,s);
