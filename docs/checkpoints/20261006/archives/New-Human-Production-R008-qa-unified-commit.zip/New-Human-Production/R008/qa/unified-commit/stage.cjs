const fs=require('node:fs'),cp=require('node:child_process'),path=require('node:path'),root=path.resolve(__dirname,'../../../../'),e=JSON.parse(fs.readFileSync(path.join(__dirname,'expected.json'),'utf8'));
function git(args){const p=cp.spawnSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});if(p.status)throw Error(p.stderr);return p.stdout;}
if(git(['rev-parse','HEAD']).trim()!==e.head||git(['diff','--cached','--name-only']).trim())throw Error('Concurrent HEAD/index change; inspect before staging');
git(['apply','--cached','--check',path.join(__dirname,'shared.patch')]);
git(['add','--',...e.own]);git(['apply','--cached',path.join(__dirname,'shared.patch')]);
const names=git(['diff','--cached','--name-only']).trim().split('\n').sort(),expected=[...e.own,...Object.keys(e.shared)].sort();
if(JSON.stringify(names)!==JSON.stringify(expected))throw Error('Unexpected staged paths');
for(const [file,text]of Object.entries(e.shared))if(git(['show',':'+file])!==text)throw Error('Unexpected staged shared content '+file);
git(['diff','--cached','--check']);console.log(git(['diff','--cached','--stat']));
