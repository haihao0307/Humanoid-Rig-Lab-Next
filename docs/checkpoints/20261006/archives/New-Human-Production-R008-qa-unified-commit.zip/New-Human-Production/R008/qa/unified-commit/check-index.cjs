const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'../../../../'),target=path.join(__dirname,'staged-check'),e=JSON.parse(fs.readFileSync(path.join(__dirname,'expected.json'),'utf8'));
function git(args,binary=false){const p=cp.spawnSync('git',args,{cwd:root,encoding:binary?null:'utf8',maxBuffer:64*1024*1024});if(p.status)throw Error(String(p.stderr));return p.stdout;}
const files=[...git(['ls-files','--','New-Human-Production/R008']).trim().split('\n'),'AGENTS.md','index.html','source/assembly.json','tools/check-r008.mjs','docs/anatomy-knowledge/README.md'];
for(const file of files){const dest=path.join(target,file);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,git(['show',':'+file],true));}
const report=JSON.parse(fs.readFileSync(path.join(root,'New-Human-Production/R008/UNIFIED_INVERSE_REVIEW_REPORT.json'),'utf8'));
console.log('Staged snapshot exported: '+files.length+' files');
const p=cp.spawnSync(process.execPath,['--input-type=module','-e',"import {checkR008} from './tools/check-r008.mjs'; console.log(JSON.stringify(checkR008(process.cwd())));"],{cwd:target,encoding:'utf8',maxBuffer:8*1024*1024});
if(p.status)throw Error(p.stdout+p.stderr);console.log(p.stdout);
