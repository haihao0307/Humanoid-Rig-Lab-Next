const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process'),crypto=require('node:crypto'),root=path.resolve(__dirname,'../../../../'),e=JSON.parse(fs.readFileSync(path.join(__dirname,'expected.json'),'utf8'));
function git(args){const p=cp.spawnSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});if(p.status)throw Error(p.stdout+p.stderr);return p.stdout;}
if(git(['rev-parse','HEAD']).trim()!==e.head)throw Error('Concurrent HEAD change');
const actual=git(['diff','--cached','--name-only']).trim().split('\n').sort(),expected=[...e.own,...Object.keys(e.shared)].sort();if(JSON.stringify(actual)!==JSON.stringify(expected))throw Error('Concurrent staged paths change');
for(const [file,text]of Object.entries(e.shared))if(git(['show',':'+file])!==text)throw Error('Concurrent staged shared content change');
for(const file of e.own)if(git(['show',':'+file])!==fs.readFileSync(path.join(root,file),'utf8').replace(/\r\n/g,'\n'))throw Error('Unstaged own change '+file);
const report=JSON.parse(git(['show',':New-Human-Production/R008/UNIFIED_INVERSE_REVIEW_REPORT.json']));
for(const [file,hash]of Object.entries(report.sourceHashes)){const data=git(['show',':New-Human-Production/R008/'+file]);if(crypto.createHash('sha256').update(data).digest('hex')!==hash)throw Error('QA hash mismatch '+file);}
git(['diff','--cached','--check']);console.log(git(['-c','user.name=Haihao_Nature Grace HK','-c','user.email=haihao0307@gmail.com','commit','-m','Unify surface inverse skeleton and muscle generation across human identities']));console.log('COMMIT='+git(['rev-parse','HEAD']).trim());
