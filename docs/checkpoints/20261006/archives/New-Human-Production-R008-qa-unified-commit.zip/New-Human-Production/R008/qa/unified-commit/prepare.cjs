const fs=require('node:fs'),path=require('node:path'),cp=require('node:child_process');
const root=path.resolve(__dirname,'../../../../'),base='New-Human-Production/R008/',own=[
 'AGENTS.md',base+'HumanInverseMethod.mjs',base+'HumanInverseSystem.mjs',base+'SurfaceSkeletonFit.mjs',base+'SurfaceSkeletonDisplay.mjs',base+'AnatomyDisplay.mjs',base+'MotionAnatomyWorkbench.mjs',base+'tools/test-human-inverse.mjs',base+'tools/unified-inverse-review.cjs',base+'UNIFIED_INVERSE_REVIEW_REPORT.json','docs/anatomy-knowledge/README.md','docs/anatomy-knowledge/UNIFIED_INVERSE_METHOD_R26.md'];
function git(args){const p=cp.spawnSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});if(p.status)throw Error(p.stderr);return p.stdout;}
function replaceOnce(s,a,b){if(!s.includes(a)||s.indexOf(a)!==s.lastIndexOf(a))throw Error('Ambiguous anchor '+a);return s.replace(a,b);}
const transforms={
 [base+'server.cjs']:s=>replaceOnce(s,'const publicFiles=new Set([',"const publicFiles=new Set(['/HumanInverseMethod.mjs','/HumanInverseSystem.mjs',"),
 'source/assembly.json':s=>replaceOnce(s,'      "surfaceSkeletonFit":','      "humanInverseMethod": "'+base+'HumanInverseMethod.mjs",\n      "humanInverseSystem": "'+base+'HumanInverseSystem.mjs",\n      "humanInverseMethodId": "human/surface-musculoskeletal-inverse@1",\n      "surfaceSkeletonFit":'),
 'tools/check-r008.mjs':s=>{
  s="import {HUMAN_INVERSE_METHOD} from '../"+base+"HumanInverseMethod.mjs';\n"+s;
  s=replaceOnce(s,' assert(selected.anatomyAnalysis'," assert(selected.humanInverseMethodId===HUMAN_INVERSE_METHOD.id&&Object.isFrozen(HUMAN_INVERSE_METHOD),'Missing fixed inverse methodology');assert(read(base+'SurfaceSkeletonDisplay.mjs').includes('createHumanInverseSystem')&&read(base+'MotionAnatomyWorkbench.mjs').includes('model:inverse.system.muscles'),'Separate inverse skeleton/muscle methods are forbidden');\n assert(selected.anatomyAnalysis");
  s=replaceOnce(s,'{surfaceSkeletonFit:',"{humanInverseMethod:'HumanInverseMethod.mjs',humanInverseSystem:'HumanInverseSystem.mjs',surfaceSkeletonFit:");
  s=replaceOnce(s,"['test-surface-skeleton.mjs'","['test-human-inverse.mjs','test-surface-skeleton.mjs'");
  return replaceOnce(s,' const modules=['," const modules=['HumanInverseMethod.mjs','HumanInverseSystem.mjs',");
 }
};
let patch='';const expected={};
for(const [file,transform] of Object.entries(transforms)){
 const before=git(['show','HEAD:'+file]).replace(/\r\n/g,'\n'),after=transform(before);
 fs.writeFileSync(path.join(__dirname,'before.txt'),before);fs.writeFileSync(path.join(__dirname,'after.txt'),after);
 const p=cp.spawnSync('git',['diff','--no-index','--no-prefix','--','before.txt','after.txt'],{cwd:__dirname,encoding:'utf8'});if(p.status!==1)throw Error(p.stderr||'Expected diff');
 const body=p.stdout.slice(p.stdout.indexOf('@@'));
 patch+=`diff --git a/${file} b/${file}\n--- a/${file}\n+++ b/${file}\n${body}`;
 expected[file]=after;
}
fs.writeFileSync(path.join(__dirname,'shared.patch'),patch);fs.writeFileSync(path.join(__dirname,'expected.json'),JSON.stringify({head:git(['rev-parse','HEAD']).trim(),own,shared:expected},null,2));
console.log(JSON.stringify({own:own.length,shared:Object.keys(expected),patchBytes:Buffer.byteLength(patch)}));
