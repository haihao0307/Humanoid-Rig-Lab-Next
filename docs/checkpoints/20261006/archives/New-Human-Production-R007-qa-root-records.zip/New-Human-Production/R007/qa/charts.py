import json,numpy as np
from collections import defaultdict,Counter
from pathlib import Path
d=json.load(open(Path(__file__).parent/'capture.json'));m=d['meshes'][0]
p=np.array(m['attributes']['position']['array']).reshape(-1,3);uv=np.array(m['attributes']['uv']['array']).reshape(-1,2)
ids={}; v=[]; xyz=[]; triangles=[]
for t in range(len(p)//3):
 tri=[]
 for i in range(t*3,t*3+3):
  key=tuple(uv[i])+tuple(p[i]);idx=ids.get(key)
  if idx is None: idx=len(v);ids[key]=idx;v.append(uv[i]);xyz.append(p[i])
  tri.append(idx)
 triangles.append(tri)
parents=list(range(len(v)))
def find(x):
 while parents[x]!=x: parents[x]=parents[parents[x]];x=parents[x]
 return x
for a,b,c in triangles:parents[find(b)]=find(a);parents[find(c)]=find(a)
groups=defaultdict(list)
for t,tri in enumerate(triangles):groups[find(tri[0])].append(t)
cs=[]
for ts in groups.values():
 vs=sorted(set(i for t in ts for i in triangles[t]));edges=Counter(tuple(sorted((a,b))) for t in ts for a,b in zip(triangles[t],triangles[t][1:]+triangles[t][:1]));a=np.array(v)[vs];cs.append({'triangles':len(ts),'vertices':len(vs),'boundaryEdges':sum(n==1 for n in edges.values()),'uvMin':a.min(axis=0).tolist(),'uvMax':a.max(axis=0).tolist(),'areaUV':sum(abs(np.cross(uv[t*3+1]-uv[t*3],uv[t*3+2]-uv[t*3]))/2 for t in ts),'sourceTriangles':ts})
cs.sort(key=lambda c:c['triangles'],reverse=True)
json.dump({'uv':np.array(v).tolist(),'positions':np.array(xyz).tolist(),'triangles':triangles,'charts':cs},open(Path(__file__).parent/'charts.json','w'))
print('chartcount',len(cs));print([{k:v for k,v in c.items() if k!='sourceTriangles'} for c in cs])
