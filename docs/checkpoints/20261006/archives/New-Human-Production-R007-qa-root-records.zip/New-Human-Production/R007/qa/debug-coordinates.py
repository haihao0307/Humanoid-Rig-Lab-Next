import json,gzip,numpy as np
from pathlib import Path
r=Path(__file__).parent.parent;data=json.loads(gzip.decompress((r/'parameters.json.gz').read_bytes()));intake=json.load(open(r/'qa/projection-charts.json'));P=np.array(intake['positions']);T=np.array(intake['triangles']);barys=np.array([[1,0,0],[0,1,0],[0,0,1],[.5,.5,0],[0,.5,.5],[.5,0,.5],[1/3,1/3,1/3]])
for idx in [6,89,11,181]:
 c=data['charts'][idx];ref=intake['charts'][idx];xyz=np.einsum('kc,tcd->tkd',barys,P[T[ref['triangles']]]).reshape(-1,3);q=(xyz[:,c['plane']]-c['lo'])/c['extent'];last=c['height']['knots'][-3:];print('chart',idx,'knots',last)
 for knot in last[-2:]:
  dist=np.linalg.norm((q-np.array(knot[:2]))*c['extent'],axis=1);ids=np.argsort(dist)[:8];print('nearest',[(int(i),float(dist[i]),xyz[i].tolist()) for i in ids])
