// Independent read-only segment algebra on the frozen failed browser section.
'use strict';
const fs=require('fs'),path=require('path');
const q=JSON.parse(fs.readFileSync(path.join(__dirname,'QA.json'))),d=q.startupState.failureDetails.details;
const loops=d.currentAllLoops.map(l=>l.sourceWitnesses),a=loops[d.selected],b=loops[d.other],hits=[];
const cross=(u,v)=>u[0]*v[1]-u[1]*v[0],xz=p=>[p[0],p[2]],sub=(u,v)=>u.map((x,k)=>x-v[k]);
for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){
 const p=xz(a[i].point),q=xz(a[(i+1)%a.length].point),r=xz(b[j].point),s=xz(b[(j+1)%b.length].point),u=sub(q,p),v=sub(s,r),w=sub(r,p),det=cross(u,v);
 if(det===0)continue;const t=cross(w,v)/det,k=cross(w,u)/det;
 if(t>0&&t<1&&k>0&&k<1){const first=p.map((x,n)=>x+t*u[n]),second=r.map((x,n)=>x+k*v[n]);hits.push({selectedEdge:i,otherEdge:j,selectedFraction:t,otherFraction:k,coordinateFrame:'actor-local metres',point:[first[0],d.y,first[1]],twoSegmentPointMismatchM:Math.hypot(...sub(first,second)),selectedTriangleIds:[a[i].triangleId,a[(i+1)%a.length].triangleId],otherTriangleIds:[b[j].triangleId,b[(j+1)%b.length].triangleId]});}
}
const r={createdAt:new Date().toISOString(),artifactSHA256:q.artifactSHA256,scope:'independent proper 2D segment intersections in captured current native source triangle-plane chains; no contour edit, tolerance adjustment, cloth solve or solid-volume claim',y:d.y,side:d.side,properCrossingCount:hits.length,hits,guardDisposition:hits.length?'HOLD_SOURCE_CONTOUR_CROSSING_CONFIRMED':'NO_PROPER_CROSSING_PROVED_BY_THIS_LIMITED_AUDIT',newGarmentExists:false,physicalWearingAccepted:false};
fs.writeFileSync(path.join(__dirname,'SOURCE_LOOP_INTERSECTION_AUDIT.json'),JSON.stringify(r,null,2));console.log(JSON.stringify(r,null,2));
