# Humanoid Rig Lab Next

Humanoid Rig Lab Next 是一个基于 WebGPU、Three.js 和多窗口共享状态的人物生产线协作平台。网站把骨骼比例、人物蒙皮、动作与物理、动画系统拆成独立工作台，同时维护同一个人物项目、骨架版本、姿势状态和审查记录。

当前母平台版本为 `0.5.0`，内置三维编辑器版本为 `V8.4`。

## V0.5.0 的重点

V0.5.0 专门修复骨骼比例工作台中两个基础问题：中央区域持续显示轻量 2D 人偶，以及比例控件修改后无法驱动真实三维骨架。

当前比例工作台默认打开 V8.4 三维骨架视口。轻量 Canvas 预览只在 Three.js 运行库无法启动时作为后备提示，不再承担正式比例编辑。

比例工作台可以实时调整：

```text
人物身高
肩关节中心宽度
髋关节中心宽度
上臂长度
前臂长度
腕到手部控制点长度
大腿长度
小腿长度
```

拖动滑块时，母平台通过同源消息把 BodyProfile 发送给 V8.4。V8.4 从不可变参考绑定骨架重新生成完整三维骨架，并返回实际测量值。松开滑块后，参数写入 SharedWorker 项目状态并同步到其他窗口。

## 比例与表皮的边界

骨骼比例修改会形成新的绑定草案。当前精细人体表皮属于参考绑定版本，比例发生变化后会显示“需要重新绑定”。比例工作台可以选择只看三维骨架，也可以把当前表皮作为对照层。

当前版本不会把旧表皮强行拉伸成已经完成的新蒙皮成果。蒙皮模块需要为发布后的新 RigDefinition 生成兼容 SkinBinding。

当前静态人体表皮和运行时实验权重仍然属于研究阶段。正式生产基线需要接入带有原生骨架、`JOINTS_0`、`WEIGHTS_0` 和逆绑定矩阵的预绑定 GLB。

## 肩带显示规则

V8.4 保留 SMPL 24 中的锁骨节点作为内部控制点。左右锁骨控制点不会显示为大关节球。每侧只显示一个真正的肩关节球，并通过锁骨骨段连接上胸和肩关节。

## 页面结构

```text
index.html
项目总控、四模块进度、版本、活动记录和审查入口

studio.html?module=proportion
三维骨骼比例工作台

studio.html?module=skin
人物蒙皮工作台

studio.html?module=pose
动作、人体物理和全身联动工作台

studio.html?module=animation
动画片段、关键帧草案和播放状态工作台

studio.html?module=integration
活动版本组合与统一人物验收

legacy/v8/index.html
V8.4 全屏三维骨架、参考表皮和人体物理编辑器
```

## 本地启动

完整解压后双击：

```text
start.bat
```

备用入口：

```text
START_HERE.cmd
```

启动器优先使用 Node.js 18 或更高版本。项目缺少本地 Three.js 运行库时，启动器会尝试安装锁定版本 `0.185.1`。Node.js 不可用时会调用 PowerShell 静态服务器，三维运行库仍需提前准备。

浏览器通常打开：

```text
http://127.0.0.1:4173/
```

端口被占用时会自动尝试后续端口。命令窗口需要保持开启。请通过 HTTP 地址运行页面，直接双击 HTML 会受到 ES Modules、SharedWorker、GLB 和 WebGPU 的本地文件限制。

升级后建议按一次：

```text
Ctrl + F5
```

V0.5.0 使用新的项目状态键和窗口通道：

```text
humanoid-rig-lab-next:project-state:v5
humanoid-rig-lab-next:project-hub:v5
humanoid-skeleton-editor:v8.4-3d-proportion
```

旧版 `v4`、`v3`、`v2` 和 `v1` 项目状态会自动迁移。

## 比例工作台操作

1. 打开 `studio.html?module=proportion`。
2. 中央视口默认显示真正的三维骨架。
3. 拖动任一比例滑块，中央骨架应实时变化。
4. 右侧“实际三维身高”和左侧“实时结果”应同步更新。
5. 松开滑块后，项目修订号增加，其他工作台收到同一 BodyProfile。
6. 点击“生成新绑定草案”，系统增加 draftRevision 并登记表皮重新绑定要求。
7. 选择“恢复参考比例”，骨架回到当前参考体型。

顶部显示按钮和左侧“中央视口”可以切换：

```text
3D 骨架
骨架和当前表皮参考
当前表皮参考
```

比例检查建议优先使用“3D 骨架”。

## 四窗口协作

总控页面可以同时打开骨骼比例、人物蒙皮、动作与物理、动画系统四个工作台。所有窗口需要使用同一浏览器配置、同一主机名和同一端口。

同步优先级：

```text
SharedWorker
BroadcastChannel
localStorage storage event
```

三维场景、相机和 GPU 对象保留在各窗口。窗口之间传输 ProjectState、ModulePatch、BodyProfile、姿势载荷、版本和审查记录。


## 四个对话分别开发

V0.5.0 已经具备四模块独立源码目录、独立状态切片和独立 moduleRevision。现在可以新开四个 ChatGPT 对话分别处理比例、蒙皮、动作和动画。

每个对话需要使用对应的模块工作包，只修改自己的可写目录。完成后把模块补丁 ZIP 和 `HANDOFF.md` 交回总控对话。详细规则见：

```text
docs/FOUR_MODULE_COLLABORATION.md
docs/CHAT_WINDOW_START_PROMPTS.md
docs/GITHUB_BRANCH_WORKFLOW.md
```

浏览器中的四个工作台负责同一项目的实时审查和状态同步。四个 ChatGPT 对话负责源代码制作。GitHub 保存经过审查的长期版本。

## GitHub 分支准备

首次将完整项目提交到 `main` 后，双击：

```text
PREPARE_BRANCHES.cmd
```

脚本会创建并推送：

```text
integration
work/proportion
work/skin
work/pose
work/animation
```

每个模块补丁提交到对应分支，再通过 Pull Request 合并到 `integration`。综合预览通过后合并到 `main`，GitHub Pages 随后发布稳定版本。

## 项目数据版本

```text
母平台 buildVersion      0.5.0
ProjectState schema      5
绑定骨架 schema          6
内置编辑器               V8.4
Three.js                 0.185.1
```

## 测试

运行：

```text
npm test
```

测试覆盖：

```text
ProjectState schema 5 和旧项目迁移
模块 Patch 并行合并
三维比例工作台为默认主视口
2D 后备层隐藏优先级
BodyProfile 实时消息协议
八项比例参数的精确三维测量
固定骨骼 ID 和左右镜像规则
隐藏锁骨控制点和唯一可见肩关节
固定骨长、刚性骨盆和人体活动范围
GLB 解析、表面实验变形和直接拾取
Windows 启动器与 GitHub Pages 工作流
```

完整结果见 `VALIDATION.md`。

## 当前限制

1. 当前精细人体表皮仍使用运行时实验权重，无法作为最终专业蒙皮成果。
2. 比例变化后需要蒙皮模块重新绑定对应表皮。
3. 完整手指骨链、姿势修正形变和生产级动画时间轴仍待后续版本。
4. 当前构建环境无法完成可信的 Windows WebGPU 实机截图，最终可见画面需要在本地 Chrome 或 Edge 中验收。

## 许可

平台代码采用 MIT License。第三方运行库与示例人体资产保留各自许可。详见：

```text
THIRD_PARTY_NOTICES.md
legacy/v8/assets/smpl/ATTRIBUTION.md
```
