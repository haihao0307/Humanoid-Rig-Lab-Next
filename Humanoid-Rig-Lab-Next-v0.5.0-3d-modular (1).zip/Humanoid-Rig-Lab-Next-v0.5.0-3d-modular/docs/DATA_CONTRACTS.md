# Humanoid Rig Lab Next 共享数据协议

当前协议版本：`schemaVersion: 5`

## 1. ProjectState

ProjectState 是多窗口协作的结构化项目状态。SharedWorker 在同源窗口中维护当前副本，BroadcastChannel 提供兼容回退，localStorage 用于恢复。

```json
{
  "schemaVersion": 5,
  "projectId": "humanoid-rig-lab-next",
  "revision": 12,
  "moduleRevisions": {
    "proportion": 4,
    "skin": 7,
    "pose": 9,
    "animation": 3,
    "integration": 5
  },
  "moduleUpdatedAt": {},
  "activeVersions": {},
  "modules": {},
  "character": {},
  "activity": [],
  "reviews": []
}
```

`revision` 记录项目整体变化次数。`moduleRevisions` 记录每个模块自己的变化节奏。每个窗口只提交本模块数据 Patch，其他模块在接近同时产生的变化会被保留。

## 2. ModulePatch

ModulePatch 是多窗口增量同步单位。

```json
{
  "module": "proportion",
  "moduleRevision": 7,
  "moduleUpdatedAt": "2026-08-19T10:00:00.000Z",
  "optimisticRevision": 12,
  "writer": "proportion:client-id",
  "moduleState": {},
  "bodyProfile": {},
  "rigRules": {},
  "activeVersion": "rig@0.4.0"
}
```

接收端比较对应模块的 revision 和更新时间。新 Patch 只合并该模块拥有的数据切片。过期 Patch 会被拒绝。

## 3. HumanoidRigModuleBundle

模块更新包用于离线交接和聊天窗口之间传递成果。

```json
{
  "type": "HumanoidRigModuleBundle",
  "schemaVersion": 5,
  "module": "proportion",
  "moduleRevision": 9,
  "compatibleRig": "rig@0.4.0",
  "generatedAt": "2026-08-19T10:00:00.000Z",
  "data": {
    "bodyProfile": {},
    "rigRules": {}
  }
}
```

模块包只能导入同名工作台。导入后会产生新的本地模块 revision，并同步到其他窗口。

## 4. BodyProfile

骨骼比例模块在 V0.5.0 中使用以下数据：

```json
{
  "preset": "smpl-male-surface-fit-1796-v3",
  "height": 1.795672,
  "shoulderWidth": 0.42,
  "hipWidth": 0.2,
  "upperArmLength": 0.277218,
  "forearmLength": 0.241402,
  "handControlLength": 0.070774,
  "thighLength": 0.425348,
  "lowerLegLength": 0.403133,
  "viewportMode": "skeleton",
  "requiresRebind": false,
  "draftRevision": 1
}
```

这些数据描述绑定骨架尺寸。动作模块不得覆盖它们。

`viewportMode` 只控制比例工作台的视口：

```text
skeleton
both
skin
```

`requiresRebind` 表示当前 BodyProfile 与已发布表皮绑定是否兼容。任一绑定尺寸变化都会将其设为 `true`。

## 5. RigRules

```json
{
  "lockBoneIds": true,
  "lockBindPoseAfterPublish": true,
  "mirrorEditing": true
}
```

这些规则用于发布校验与数据一致性。它们没有必要产生立即可见的形体变化。

## 6. 三维比例视口协议

母平台和 V8.4 iframe 使用同源 `postMessage`。

母平台发送：

```text
HRL_HOST_STATE
HRL_PREVIEW_BODY_PROFILE
```

V8.4 返回：

```text
HRL_EMBED_READY
HRL_RENDERER_STATUS
HRL_PROFILE_STATUS
HRL_SURFACE_STATUS
HRL_POSE_COMMIT
HRL_HOST_ACK
```

`HRL_PREVIEW_BODY_PROFILE` 用于滑块拖动过程。它不会直接增加项目 revision。

`HRL_PROFILE_STATUS` 返回：

```json
{
  "preview": true,
  "bodyProfile": {},
  "metrics": {
    "height": 1.8,
    "shoulderWidth": 0.42,
    "hipWidth": 0.2,
    "upperArmLength": 0.277,
    "forearmLength": 0.241,
    "handControlLength": 0.071,
    "thighLength": 0.425,
    "lowerLegLength": 0.403
  },
  "requiresSkinRebind": true
}
```

## 7. RigDefinition

骨骼比例模块拥有：

```text
骨骼 ID
父子层级
绑定姿势
绑定局部变换
固定骨长
关节轴
关节活动范围
镜像关系
人体比例参数
```

发布后的 RigDefinition 保持不可变。比例变化生成新的绑定草案和兼容报告。

当前导出 `schemaVersion` 为 `6`。SMPL collar 节点保留为隐藏控制点，每侧 `UpperArm` 节点作为可见肩关节。

## 8. SkinBinding 与 SurfaceState

蒙皮模块拥有：

```text
网格资产 ID
兼容骨架版本
Skin Index
Skin Weight
逆绑定矩阵
材质
Morph Target
表皮显示参数
```

当前精细表面协议仍保留：

```json
{
  "source": "detail",
  "activeSource": "detail",
  "singleLayer": true,
  "detailAsset": "legacy/v8/assets/smpl/smpl-male-surface.glb",
  "pickingSource": "detailed-smpl-mesh",
  "deformation": "region-isolated-dqs",
  "bindPoseProtection": true,
  "reloadToken": 0
}
```

这条表面路径用于研究和参考。BodyProfile 改变后需要生成兼容的新 SkinBinding。

## 9. PoseSnapshot 与 ConstraintProfile

动作模块拥有单帧姿势、IK 目标、固定关节、人体约束、地面碰撞和求解器参数。PoseSnapshot 不得写入绑定骨长。

完整三维姿势保存在 `v8Payload`，通过动作模块 Patch 同步。

## 10. AnimationClip 与 AnimationGraph

动画模块拥有动画片段、时间轴、关键帧、插值、循环、事件、混合和重定向映射。动画轨道必须声明兼容骨架版本。

## 11. 兼容与迁移

V0.5.0 可以读取旧项目状态键：

```text
project-state:v4
project-state:v3
project-state:v2
project-state:v1
```

迁移时会补齐：

```text
schemaVersion 5
BodyProfile 新字段
RigRules
五个模块 revision
表皮兼容字段
动作物理参数
动画关键帧数组
```
