import { BUILD_VERSION, MODULE_IDS, SCHEMA_VERSION, createDefaultState } from './default-state.js';

const MODULE_SET = new Set(MODULE_IDS);
const SURFACE_SOURCES = new Set(['detail']);
const DISPLAY_MODES = new Set(['skin', 'skeleton', 'both']);

export function normalizeModuleId(value) {
  if (MODULE_SET.has(value)) return value;
  if (value === 'dashboard' || value === 'system') return 'integration';
  return 'integration';
}

export function normalizeProjectState(input) {
  const defaults = createDefaultState();
  const source = input && typeof input === 'object' ? structuredClone(input) : {};
  const state = mergeDefaults(defaults, source);
  state.schemaVersion = SCHEMA_VERSION;
  state.projectId = String(state.projectId || defaults.projectId);
  state.projectName = String(state.projectName || defaults.projectName);
  state.revision = Math.max(1, Number(state.revision || 1));
  state.updatedAt = validIso(state.updatedAt) ? state.updatedAt : new Date().toISOString();
  state.build = { ...defaults.build, ...(state.build || {}), version: BUILD_VERSION };

  state.moduleRevisions = state.moduleRevisions || {};
  state.moduleUpdatedAt = state.moduleUpdatedAt || {};
  for (const id of MODULE_IDS) {
    state.moduleRevisions[id] = Math.max(1, Number(state.moduleRevisions[id] || 1));
    state.moduleUpdatedAt[id] = validIso(state.moduleUpdatedAt[id]) ? state.moduleUpdatedAt[id] : state.updatedAt;
    state.modules[id] = mergeDefaults(defaults.modules[id], state.modules?.[id] || {});
  }

  const profile = state.character.bodyProfile;
  profile.height = clamp(Number(profile.height), 1.40, 2.15, defaults.character.bodyProfile.height);
  profile.shoulderWidth = clamp(Number(profile.shoulderWidth), 0.28, 0.58, defaults.character.bodyProfile.shoulderWidth);
  profile.hipWidth = clamp(Number(profile.hipWidth), 0.14, 0.38, defaults.character.bodyProfile.hipWidth);
  profile.upperArmLength = clamp(Number(profile.upperArmLength), 0.20, 0.40, defaults.character.bodyProfile.upperArmLength);
  profile.forearmLength = clamp(Number(profile.forearmLength), 0.18, 0.36, defaults.character.bodyProfile.forearmLength);
  profile.handControlLength = clamp(Number(profile.handControlLength), 0.04, 0.12, defaults.character.bodyProfile.handControlLength);
  profile.thighLength = clamp(Number(profile.thighLength), 0.30, 0.56, defaults.character.bodyProfile.thighLength);
  profile.lowerLegLength = clamp(Number(profile.lowerLegLength), 0.30, 0.54, defaults.character.bodyProfile.lowerLegLength);
  profile.viewportMode = DISPLAY_MODES.has(profile.viewportMode) ? profile.viewportMode : 'skeleton';
  profile.requiresRebind = Boolean(profile.requiresRebind);
  profile.draftRevision = Math.max(1, Number(profile.draftRevision || 1));
  state.character.rigRules = mergeDefaults(defaults.character.rigRules, state.character.rigRules || {});
  state.character.rigRules.lockBoneIds = state.character.rigRules.lockBoneIds !== false;
  state.character.rigRules.lockBindPoseAfterPublish = state.character.rigRules.lockBindPoseAfterPublish !== false;
  state.character.rigRules.mirrorEditing = state.character.rigRules.mirrorEditing !== false;

  state.character.display.mode = DISPLAY_MODES.has(state.character.display.mode) ? state.character.display.mode : 'both';
  state.character.display.skinVisible = state.character.display.mode !== 'skeleton';
  state.character.display.skeletonVisible = state.character.display.mode !== 'skin';
  state.character.display.skinOpacity = clamp(Number(state.character.display.skinOpacity), 0.15, 1, 0.92);
  state.character.skin.source = SURFACE_SOURCES.has(state.character.skin.source) ? state.character.skin.source : 'detail';
  state.character.skin.activeSource = 'detail';
  state.character.skin.singleLayer = true;
  state.character.skin.pickingSource = 'detailed-smpl-mesh';
  state.character.skin.deformation = 'region-isolated-dqs';
  state.character.skin.bindPoseProtection = true;
  delete state.character.skin.fallbackAsset;
  state.character.skin.reloadToken = Math.max(0, Number(state.character.skin.reloadToken || 0));
  state.character.pose.v8Payload = state.character.pose.v8Payload && typeof state.character.pose.v8Payload === 'object'
    ? state.character.pose.v8Payload
    : null;
  state.character.animation.keyframes = Array.isArray(state.character.animation.keyframes) ? state.character.animation.keyframes : [];
  state.activity = uniqueById(Array.isArray(state.activity) ? state.activity : []).slice(0, 100);
  state.reviews = uniqueById(Array.isArray(state.reviews) ? state.reviews : []).slice(0, 100);
  state.collaboration = mergeDefaults(defaults.collaboration, state.collaboration || {});
  return state;
}

export function createModulePatch(nextState, module, activityEntry = null) {
  const id = normalizeModuleId(module);
  const state = normalizeProjectState(nextState);
  const patch = {
    module: id,
    moduleRevision: state.moduleRevisions[id],
    moduleUpdatedAt: state.moduleUpdatedAt[id],
    optimisticRevision: state.revision,
    activityEntry: activityEntry ? structuredClone(activityEntry) : null,
    writer: state.collaboration.lastWriterByModule?.[id] || state.collaboration.lastWriter || null,
    moduleState: id === 'integration' ? null : structuredClone(state.modules[id])
  };

  if (id === 'proportion') {
    patch.bodyProfile = structuredClone(state.character.bodyProfile);
    patch.rigRules = structuredClone(state.character.rigRules);
    patch.activeVersion = state.activeVersions.rig;
  } else if (id === 'skin') {
    patch.display = structuredClone(state.character.display);
    patch.skin = structuredClone(state.character.skin);
    patch.activeVersion = state.activeVersions.skin;
  } else if (id === 'pose') {
    patch.pose = structuredClone(state.character.pose);
    patch.physics = structuredClone(state.character.physics);
    patch.activeVersion = state.activeVersions.pose;
  } else if (id === 'animation') {
    patch.animation = structuredClone(state.character.animation);
    patch.activeVersion = state.activeVersions.animation;
  } else {
    patch.activeVersions = structuredClone(state.activeVersions);
    patch.display = structuredClone(state.character.display);
    patch.reviews = structuredClone(state.reviews);
  }
  return patch;
}

export function applyModulePatch(currentState, incomingPatch) {
  const state = normalizeProjectState(currentState);
  const patch = incomingPatch && typeof incomingPatch === 'object' ? incomingPatch : {};
  const id = normalizeModuleId(patch.module);
  const incomingRevision = Math.max(1, Number(patch.moduleRevision || 1));
  const localRevision = Math.max(1, Number(state.moduleRevisions[id] || 1));
  const incomingTime = Date.parse(patch.moduleUpdatedAt || 0) || 0;
  const localTime = Date.parse(state.moduleUpdatedAt[id] || 0) || 0;
  if (incomingRevision < localRevision || (incomingRevision === localRevision && incomingTime < localTime)) {
    return { state, accepted: false, module: id };
  }

  if (id !== 'integration' && patch.moduleState) state.modules[id] = mergeDefaults(state.modules[id], patch.moduleState);
  if (id === 'proportion') {
    if (patch.bodyProfile) state.character.bodyProfile = mergeDefaults(state.character.bodyProfile, patch.bodyProfile);
    if (patch.rigRules) state.character.rigRules = mergeDefaults(state.character.rigRules, patch.rigRules);
    if (patch.activeVersion) state.activeVersions.rig = String(patch.activeVersion);
  } else if (id === 'skin') {
    if (patch.display) state.character.display = mergeDefaults(state.character.display, patch.display);
    if (patch.skin) state.character.skin = mergeDefaults(state.character.skin, patch.skin);
    if (patch.activeVersion) state.activeVersions.skin = String(patch.activeVersion);
  } else if (id === 'pose') {
    if (patch.pose) state.character.pose = mergeDefaults(state.character.pose, patch.pose);
    if (patch.physics) state.character.physics = mergeDefaults(state.character.physics, patch.physics);
    if (patch.activeVersion) state.activeVersions.pose = String(patch.activeVersion);
  } else if (id === 'animation') {
    if (patch.animation) state.character.animation = mergeDefaults(state.character.animation, patch.animation);
    if (patch.activeVersion) state.activeVersions.animation = String(patch.activeVersion);
  } else {
    if (patch.activeVersions) state.activeVersions = mergeDefaults(state.activeVersions, patch.activeVersions);
    if (patch.display) state.character.display = mergeDefaults(state.character.display, patch.display);
    if (Array.isArray(patch.reviews)) state.reviews = uniqueById([...patch.reviews, ...state.reviews]).slice(0, 100);
  }

  const now = validIso(patch.moduleUpdatedAt) ? patch.moduleUpdatedAt : new Date().toISOString();
  state.moduleRevisions[id] = incomingRevision;
  state.moduleUpdatedAt[id] = now;
  state.revision = Math.max(Number(state.revision || 0) + 1, Number(patch.optimisticRevision || 0));
  state.updatedAt = now;
  state.collaboration.lastWriterByModule[id] = patch.writer || null;
  state.collaboration.lastWriter = patch.writer || state.collaboration.lastWriter;
  if (patch.activityEntry?.id) state.activity = uniqueById([patch.activityEntry, ...state.activity]).slice(0, 100);
  return { state: normalizeProjectState(state), accepted: true, module: id };
}

function mergeDefaults(defaultValue, sourceValue) {
  if (Array.isArray(defaultValue)) return Array.isArray(sourceValue) ? structuredClone(sourceValue) : structuredClone(defaultValue);
  if (!isPlainObject(defaultValue)) return sourceValue === undefined ? defaultValue : sourceValue;
  const result = {};
  const source = isPlainObject(sourceValue) ? sourceValue : {};
  for (const [key, value] of Object.entries(defaultValue)) result[key] = mergeDefaults(value, source[key]);
  for (const [key, value] of Object.entries(source)) if (!(key in result)) result[key] = structuredClone(value);
  return result;
}

function uniqueById(items) {
  const seen = new Set();
  return items.filter((item) => {
    const id = item?.id;
    if (!id || seen.has(id)) return false;
    seen.add(id);
    return true;
  });
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function validIso(value) {
  return Number.isFinite(Date.parse(value || ''));
}

function clamp(value, min, max, fallback) {
  if (!Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}
