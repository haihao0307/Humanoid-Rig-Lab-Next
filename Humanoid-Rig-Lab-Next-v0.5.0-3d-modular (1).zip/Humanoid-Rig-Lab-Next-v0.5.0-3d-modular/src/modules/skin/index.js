import { bindToggle, controlSection, rangeControl, toggleControl } from '../../workspace-common.js';

export function renderControls(context, state) {
  const display = state.character.display;
  context.elements.moduleControls.innerHTML =
    controlSection('表皮显示', `
      ${toggleControl('skinVisibleToggle', '显示人物表皮', display.skinVisible)}
      ${toggleControl('skeletonVisibleToggle', '显示内部骨架', display.skeletonVisible)}
      ${rangeControl('skinOpacityControl', '表皮透明度', .15, 1, .01, display.skinOpacity, '')}
      <div class="control-row"><label for="surfaceMode">表皮模式</label><select id="surfaceMode"><option value="solid">实体</option><option value="translucent">半透明</option><option value="wireframe">线框检查</option></select></div>`) +
    controlSection('唯一精细表皮', `
      <div class="toggle-row"><span>渲染人体网格</span><b style="font-size:9px;color:#63dda5">精细 SMPL · 1 套</b></div>
      <div class="toggle-row"><span>鼠标拾取来源</span><b style="font-size:9px">同一精细网格</b></div>
      <div class="toggle-row"><span>黄色代理人体</span><b style="font-size:9px;color:#63dda5">已移除</b></div>
      <p class="control-note">精细人体网格同时承担显示、鼠标拾取和姿势变形。点击关节后只高亮骨架，人体表面不会切换黄色材质。</p>
      <div class="control-button-grid"><button class="control-button" id="openLegacySkin">显示统一人物视口</button><button class="control-button" id="reloadSurface">重新加载精细表皮</button></div>`) +
    controlSection('绑定质量', `
      <div class="toggle-row"><span>绑定姿势原始顶点</span><b style="font-size:9px;color:#63dda5">保护开启</b></div>
      <div class="toggle-row"><span>权重区域隔离</span><b style="font-size:9px;color:#63dda5">躯干 / 四肢</b></div>
      <div class="toggle-row"><span>权重邻接平滑</span><b style="font-size:9px;color:#63dda5">3 轮</b></div>
      <div class="toggle-row"><span>每顶点最多影响</span><b style="font-size:9px">4 骨骼</b></div>
      <div class="toggle-row"><span>变形方式</span><b style="font-size:9px">双四元数</b></div>`);

  const surfaceMode = document.querySelector('#surfaceMode');
  if (surfaceMode) surfaceMode.value = display.surfaceMode || 'solid';

  bindToggle('skinVisibleToggle', (value) => context.hub.transaction((next) => {
    next.character.display.skinVisible = value;
    if (!value && !next.character.display.skeletonVisible) next.character.display.skeletonVisible = true;
    syncDisplayMode(next);
  }, { module: 'skin', summary: `${value ? '显示' : '隐藏'}人物表皮` }));

  bindToggle('skeletonVisibleToggle', (value) => context.hub.transaction((next) => {
    next.character.display.skeletonVisible = value;
    if (!value && !next.character.display.skinVisible) next.character.display.skinVisible = true;
    syncDisplayMode(next);
  }, { module: 'skin', summary: `${value ? '显示' : '隐藏'}内部骨架` }));

  const opacity = document.querySelector('#skinOpacityControl');
  opacity?.addEventListener('input', () => { document.querySelector('#skinOpacityControlOutput').value = opacity.value; });
  opacity?.addEventListener('change', () => context.hub.transaction((next) => {
    next.character.display.skinOpacity = Number(opacity.value);
  }, { module: 'skin', summary: `表皮透明度调整为 ${opacity.value}` }));

  surfaceMode?.addEventListener('change', () => context.hub.transaction((next) => {
    next.character.display.surfaceMode = surfaceMode.value;
  }, { module: 'skin', summary: `表皮模式切换为 ${surfaceMode.value}` }));

  document.querySelector('#openLegacySkin')?.addEventListener('click', () => context.showLegacy({ surfaceSource: 'detail' }));
  document.querySelector('#reloadSurface')?.addEventListener('click', () => context.hub.transaction((next) => {
    next.character.skin.source = 'detail';
    next.character.skin.activeSource = 'detail';
    next.character.skin.singleLayer = true;
    next.character.skin.reloadToken += 1;
    next.modules.skin.status = 'testing';
    next.modules.skin.statusLabel = '内部测试';
    next.modules.skin.currentTask = '重新检查唯一精细表皮、直接拾取与肩部变形';
  }, { module: 'skin', summary: '请求重新加载唯一精细人物表皮' }));
}

function syncDisplayMode(state) {
  const display = state.character.display;
  display.mode = display.skinVisible && display.skeletonVisible ? 'both' : display.skinVisible ? 'skin' : 'skeleton';
}

export function exportData(state) {
  return { display: structuredClone(state.character.display), skin: structuredClone(state.character.skin) };
}

export function resetData(state, defaults) {
  state.character.display = structuredClone(defaults.character.display);
  state.character.skin = structuredClone(defaults.character.skin);
}

export function publishData(state, version) {
  state.modules.skin.version = version;
  state.modules.skin.status = 'published';
  state.modules.skin.statusLabel = '已发布';
  state.modules.skin.progress = Math.max(state.modules.skin.progress, 70);
  state.modules.skin.currentTask = '等待多姿势下的肩、髋、肘和膝视觉审查';
  state.modules.skin.compatibleRig = state.activeVersions.rig;
  state.activeVersions.skin = version;
}
