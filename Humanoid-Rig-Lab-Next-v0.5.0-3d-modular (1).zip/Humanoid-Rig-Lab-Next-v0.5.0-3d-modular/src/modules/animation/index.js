import { bindNumericRange, bindToggle, controlSection, rangeControl, toggleControl } from '../../workspace-common.js';

export function renderControls(context, state) {
  const animation = state.character.animation;
  context.elements.moduleControls.innerHTML =
    controlSection('动画片段', `
      <div class="control-row"><label for="clipSelect">当前片段</label><select id="clipSelect"><option value="idle-breathe">Idle Breathe</option><option value="wave">Wave</option><option value="walk">Walk Cycle</option><option value="custom">Custom Draft</option></select></div>
      <div class="control-button-grid"><button class="control-button" id="playAnimation">${animation.playing ? '暂停' : '播放'}</button><button class="control-button" id="stopAnimation">停止</button></div>`) +
    controlSection('时间轴', `
      ${rangeControl('animationTimeControl', '当前时间', 0, animation.duration, .01, animation.time, ' s')}
      ${rangeControl('animationSpeedControl', '播放速度', .25, 2, .05, animation.speed, '×')}
      ${toggleControl('animationLoop', '循环播放', animation.loop)}
      <div class="toggle-row"><span>关键帧草案</span><b style="font-size:9px">${animation.keyframes.length} 帧</b></div>`) +
    controlSection('动作到动画', `<p class="control-note">动作工作台发布的 PoseSnapshot 可以作为动画关键帧。当前版本先保存动作快照和时间位置。</p><div class="control-button-grid"><button class="control-button" id="capturePoseKey">加入当前动作关键帧</button><button class="control-button" id="clearKeys">清空草案</button></div>`);

  const clip = document.querySelector('#clipSelect');
  if (clip) clip.value = animation.clip;
  clip?.addEventListener('change', () => context.hub.transaction((next) => {
    next.character.animation.clip = clip.value;
    next.character.animation.time = 0;
  }, { module: 'animation', summary: `切换动画片段 ${clip.value}` }));

  document.querySelector('#playAnimation')?.addEventListener('click', () => context.hub.transaction((next) => {
    next.character.animation.playing = !next.character.animation.playing;
  }, { module: 'animation', summary: `${animation.playing ? '暂停' : '播放'}动画` }));
  document.querySelector('#stopAnimation')?.addEventListener('click', () => context.hub.transaction((next) => {
    next.character.animation.playing = false;
    next.character.animation.time = 0;
  }, { module: 'animation', summary: '停止动画并返回起点' }));

  bindNumericRange({ id: 'animationTimeControl', hub: context.hub, path: 'character.animation.time', module: 'animation', label: '时间轴位置', suffix: ' s' });
  bindNumericRange({ id: 'animationSpeedControl', hub: context.hub, path: 'character.animation.speed', module: 'animation', label: '动画速度', suffix: '×' });
  bindToggle('animationLoop', (value) => context.hub.transaction((next) => {
    next.character.animation.loop = value;
  }, { module: 'animation', summary: `${value ? '开启' : '关闭'}动画循环` }));

  document.querySelector('#capturePoseKey')?.addEventListener('click', () => context.hub.transaction((next) => {
    const keyframe = {
      id: crypto.randomUUID(),
      time: Number(next.character.animation.time.toFixed(3)),
      poseName: next.character.pose.name,
      pose: structuredClone(next.character.pose.joints),
      sourcePoseVersion: next.activeVersions.pose,
    };
    next.character.animation.keyframes = [
      ...next.character.animation.keyframes.filter((item) => Math.abs(item.time - keyframe.time) > 0.0005),
      keyframe,
    ].sort((a, b) => a.time - b.time);
    next.modules.animation.completed = Math.min(next.modules.animation.total, next.modules.animation.completed + 1);
    next.modules.animation.progress = Math.min(95, next.modules.animation.progress + 4);
    next.modules.animation.status = 'developing';
    next.modules.animation.statusLabel = '功能开发';
  }, { module: 'animation', summary: '将当前动作快照加入动画关键帧草案' }));

  document.querySelector('#clearKeys')?.addEventListener('click', () => context.hub.transaction((next) => {
    next.character.animation.keyframes = [];
  }, { module: 'animation', summary: '清空动画关键帧草案' }));
}

export function exportData(state) {
  return { animation: structuredClone(state.character.animation) };
}

export function resetData(state, defaults) {
  state.character.animation = structuredClone(defaults.character.animation);
}

export function publishData(state, version) {
  state.modules.animation.version = version;
  state.modules.animation.status = 'published';
  state.modules.animation.statusLabel = '已发布';
  state.modules.animation.progress = Math.max(state.modules.animation.progress, 60);
  state.modules.animation.currentTask = '等待完整三维时间轴和局部四元数轨道接入';
  state.modules.animation.compatibleRig = state.activeVersions.rig;
  state.activeVersions.animation = version;
}
