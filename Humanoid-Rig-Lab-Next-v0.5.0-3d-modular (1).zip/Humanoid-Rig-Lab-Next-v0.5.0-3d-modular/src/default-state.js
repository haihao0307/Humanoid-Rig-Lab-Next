export const BUILD_VERSION = '0.5.0';
export const SCHEMA_VERSION = 5;
export const MODULE_IDS = Object.freeze(['proportion', 'skin', 'pose', 'animation', 'integration']);

const JOINTS = {
  headTop: { x: 0, y: 0.985 },
  head: { x: 0, y: 0.925 },
  neck: { x: 0, y: 0.855 },
  chest: { x: 0, y: 0.755 },
  spine: { x: 0, y: 0.645 },
  pelvis: { x: 0, y: 0.525 },
  leftShoulder: { x: -0.145, y: 0.79 },
  leftElbow: { x: -0.275, y: 0.675 },
  leftWrist: { x: -0.365, y: 0.575 },
  leftHand: { x: -0.405, y: 0.54 },
  rightShoulder: { x: 0.145, y: 0.79 },
  rightElbow: { x: 0.275, y: 0.675 },
  rightWrist: { x: 0.365, y: 0.575 },
  rightHand: { x: 0.405, y: 0.54 },
  leftHip: { x: -0.075, y: 0.505 },
  leftKnee: { x: -0.08, y: 0.285 },
  leftAnkle: { x: -0.085, y: 0.075 },
  leftToe: { x: -0.125, y: 0.025 },
  rightHip: { x: 0.075, y: 0.505 },
  rightKnee: { x: 0.08, y: 0.285 },
  rightAnkle: { x: 0.085, y: 0.075 },
  rightToe: { x: 0.125, y: 0.025 }
};

const MODULES = {
  proportion: {
    id: 'proportion', title: '骨骼比例', shortTitle: '比例', status: 'developing', statusLabel: '功能开发',
    progress: 58, version: 'rig@0.4.0', compatibleRig: 'rig@0.4.0',
    currentTask: '验证所有比例滑块对统一三维骨架的实时反馈与绑定草案生成', completed: 12, total: 18, passed: 29, failed: 0,
    blockers: [], color: '#58c7ff'
  },
  skin: {
    id: 'skin', title: '人物蒙皮', shortTitle: '蒙皮', status: 'testing', statusLabel: '内部测试',
    progress: 58, version: 'skin@0.4.0', compatibleRig: 'rig@0.4.0',
    currentTask: '验证唯一精细网格、直接表面拾取、绑定姿势保护与肩部双四元数变形', completed: 13, total: 20, passed: 30, failed: 0,
    blockers: ['正式 SMPL 权重与姿势修正形变仍待许可资产'], color: '#ff9f68'
  },
  pose: {
    id: 'pose', title: '动作与物理', shortTitle: '动作', status: 'developing', statusLabel: '功能开发',
    progress: 41, version: 'pose@0.3.1', compatibleRig: 'rig@0.4.0',
    currentTask: '在更新后的解剖拟合骨架上复核固定骨长、刚性骨盆与全身联动', completed: 9, total: 20, passed: 24, failed: 0,
    blockers: [], color: '#7fe0ad'
  },
  animation: {
    id: 'animation', title: '动画系统', shortTitle: '动画', status: 'architecture', statusLabel: '架构搭建',
    progress: 14, version: 'anim@0.2.0', compatibleRig: 'rig@0.4.0',
    currentTask: '建立关键帧草案、片段协议与动作快照引用', completed: 3, total: 19, passed: 5, failed: 0,
    blockers: ['完整三维时间轴依赖动作四元数协议'], color: '#c6a6ff'
  }
};

export function createDefaultState() {
  const now = new Date().toISOString();
  const moduleRevisions = Object.fromEntries(MODULE_IDS.map((id) => [id, 1]));
  const moduleUpdatedAt = Object.fromEntries(MODULE_IDS.map((id) => [id, now]));
  return {
    schemaVersion: SCHEMA_VERSION,
    projectId: 'humanoid-rig-lab-next',
    projectName: 'Humanoid Rig Lab Next',
    revision: 1,
    updatedAt: now,
    moduleRevisions,
    moduleUpdatedAt,
    build: {
      version: BUILD_VERSION,
      channel: 'local-review',
      source: 'ChatGPT direct build',
      commit: 'not-synced'
    },
    activeVersions: {
      rig: 'rig@0.4.0', skin: 'skin@0.4.0', pose: 'pose@0.3.1', animation: 'anim@0.2.0', character: 'character@0.5.0'
    },
    modules: structuredClone(MODULES),
    character: {
      bodyProfile: {
        preset: 'smpl-male-surface-fit-1796-v3', height: 1.795672, shoulderWidth: 0.42, hipWidth: 0.20,
        upperArmLength: 0.277218, forearmLength: 0.241402, handControlLength: 0.070774,
        thighLength: 0.425348, lowerLegLength: 0.403133,
        viewportMode: 'skeleton', requiresRebind: false, draftRevision: 1
      },
      rigRules: {
        lockBoneIds: true, lockBindPoseAfterPublish: true, mirrorEditing: true
      },
      display: {
        mode: 'both', skinVisible: true, skeletonVisible: true, skinOpacity: 0.92,
        surfaceMode: 'solid', gridVisible: true
      },
      skin: {
        source: 'detail',
        activeSource: 'detail',
        singleLayer: true,
        detailAsset: 'legacy/v8/assets/smpl/smpl-male-surface.glb',
        pickingSource: 'detailed-smpl-mesh',
        deformation: 'region-isolated-dqs',
        bindPoseProtection: true,
        reloadToken: 0
      },
      pose: {
        name: 'A Pose', joints: structuredClone(JOINTS), pinned: ['leftAnkle', 'rightAnkle'], v8Payload: null
      },
      physics: {
        bodyCoupling: 0.8, damping: 0.92, jointLimits: true, groundEnabled: true
      },
      animation: {
        clip: 'idle-breathe', playing: false, time: 0, duration: 3.2, speed: 1, loop: true,
        keyframes: []
      }
    },
    collaboration: {
      onlineWindows: 1,
      lastWriter: 'initial-state',
      lastWriterByModule: Object.fromEntries(MODULE_IDS.map((id) => [id, null])),
      lock: null
    },
    activity: [{
      id: crypto.randomUUID(), at: now, module: 'system',
      summary: '创建母平台 V0.5.0 统一三维比例工作台与实时绑定尺寸反馈版本'
    }],
    reviews: []
  };
}
