const GLB_MAGIC = 0x46546c67;
const JSON_CHUNK = 0x4e4f534a;
const BIN_CHUNK = 0x004e4942;

const COMPONENT_INFO = Object.freeze({
  5120: { ArrayType: Int8Array, bytes: 1, getter: 'getInt8' },
  5121: { ArrayType: Uint8Array, bytes: 1, getter: 'getUint8' },
  5122: { ArrayType: Int16Array, bytes: 2, getter: 'getInt16' },
  5123: { ArrayType: Uint16Array, bytes: 2, getter: 'getUint16' },
  5125: { ArrayType: Uint32Array, bytes: 4, getter: 'getUint32' },
  5126: { ArrayType: Float32Array, bytes: 4, getter: 'getFloat32' },
});

const TYPE_SIZE = Object.freeze({
  SCALAR: 1,
  VEC2: 2,
  VEC3: 3,
  VEC4: 4,
  MAT2: 4,
  MAT3: 9,
  MAT4: 16,
});

/**
 * Loads the first triangle mesh from a binary glTF file without GLTFLoader.
 * The project surface asset only needs positions, normals, colors and indices,
 * so keeping this parser local removes the fragile three/addons dependency.
 */
export async function loadGlbMesh(url, { signal } = {}) {
  const response = await fetch(url, { cache: 'force-cache', signal });
  if (!response.ok) {
    throw new Error(`人体表皮文件加载失败：HTTP ${response.status}`);
  }
  return parseGlbMesh(await response.arrayBuffer());
}

export function parseGlbMesh(arrayBuffer) {
  if (!(arrayBuffer instanceof ArrayBuffer)) {
    throw new TypeError('GLB 解析器需要 ArrayBuffer。');
  }
  if (arrayBuffer.byteLength < 20) {
    throw new Error('GLB 文件过短。');
  }

  const view = new DataView(arrayBuffer);
  const magic = view.getUint32(0, true);
  const version = view.getUint32(4, true);
  const declaredLength = view.getUint32(8, true);
  if (magic !== GLB_MAGIC) {
    throw new Error('文件不是有效的 GLB。');
  }
  if (version !== 2) {
    throw new Error(`仅支持 GLB 2.0，当前版本为 ${version}。`);
  }
  if (declaredLength > arrayBuffer.byteLength) {
    throw new Error('GLB 文件内容不完整。');
  }

  let json = null;
  let binaryChunk = null;
  let offset = 12;
  while (offset + 8 <= declaredLength) {
    const chunkLength = view.getUint32(offset, true);
    const chunkType = view.getUint32(offset + 4, true);
    offset += 8;
    if (offset + chunkLength > declaredLength) {
      throw new Error('GLB 数据块长度越界。');
    }
    if (chunkType === JSON_CHUNK) {
      const bytes = new Uint8Array(arrayBuffer, offset, chunkLength);
      const text = new TextDecoder().decode(bytes).replace(/[\u0000\u0020]+$/g, '');
      json = JSON.parse(text);
    } else if (chunkType === BIN_CHUNK && !binaryChunk) {
      binaryChunk = {
        buffer: arrayBuffer,
        byteOffset: offset,
        byteLength: chunkLength,
      };
    }
    offset += chunkLength;
  }

  if (!json || !binaryChunk) {
    throw new Error('GLB 缺少 JSON 或 BIN 数据块。');
  }

  const primitive = findFirstTrianglePrimitive(json);
  const attributes = {};
  for (const [semantic, accessorIndex] of Object.entries(primitive.attributes ?? {})) {
    const key = semanticToKey(semantic);
    if (!key) continue;
    attributes[key] = readAccessor(json, binaryChunk, accessorIndex);
  }
  if (!attributes.position) {
    throw new Error('GLB 网格缺少 POSITION 属性。');
  }

  const index = Number.isInteger(primitive.indices)
    ? readAccessor(json, binaryChunk, primitive.indices)
    : null;
  if (index && index.itemSize !== 1) {
    throw new Error('GLB 索引访问器必须是 SCALAR。');
  }

  return {
    attributes,
    index,
    mode: primitive.mode ?? 4,
    vertexCount: attributes.position.count,
    triangleCount: index
      ? Math.floor(index.count / 3)
      : Math.floor(attributes.position.count / 3),
    metadata: {
      asset: json.asset ?? {},
      meshName: json.meshes?.find((mesh) => mesh.primitives?.includes(primitive))?.name ?? '',
      bounds: {
        min: attributes.position.min ?? null,
        max: attributes.position.max ?? null,
      },
    },
  };
}

function findFirstTrianglePrimitive(json) {
  for (const mesh of json.meshes ?? []) {
    for (const primitive of mesh.primitives ?? []) {
      const mode = primitive.mode ?? 4;
      if (mode === 4 && primitive.attributes?.POSITION != null) {
        return primitive;
      }
    }
  }
  throw new Error('GLB 中没有三角形人体网格。');
}

function semanticToKey(semantic) {
  if (semantic === 'POSITION') return 'position';
  if (semantic === 'NORMAL') return 'normal';
  if (semantic === 'COLOR_0') return 'color';
  if (semantic === 'TEXCOORD_0') return 'uv';
  return null;
}

function readAccessor(json, binaryChunk, accessorIndex) {
  const accessor = json.accessors?.[accessorIndex];
  if (!accessor) {
    throw new Error(`GLB accessor ${accessorIndex} 不存在。`);
  }
  if (accessor.sparse) {
    throw new Error('当前本地 GLB 解析器暂不支持 sparse accessor。');
  }
  const bufferView = json.bufferViews?.[accessor.bufferView];
  if (!bufferView) {
    throw new Error(`GLB accessor ${accessorIndex} 缺少 bufferView。`);
  }
  if ((bufferView.buffer ?? 0) !== 0) {
    throw new Error('当前本地 GLB 解析器只支持单个内嵌 BIN 缓冲区。');
  }

  const component = COMPONENT_INFO[accessor.componentType];
  const itemSize = TYPE_SIZE[accessor.type];
  if (!component || !itemSize) {
    throw new Error(`不支持的 GLB accessor 类型：${accessor.componentType}/${accessor.type}`);
  }

  const count = Number(accessor.count ?? 0);
  const packedStride = component.bytes * itemSize;
  const stride = Number(bufferView.byteStride ?? packedStride);
  const relativeOffset = Number(bufferView.byteOffset ?? 0) + Number(accessor.byteOffset ?? 0);
  const byteOffset = binaryChunk.byteOffset + relativeOffset;
  const requiredEnd = byteOffset + (Math.max(0, count - 1) * stride) + packedStride;
  const binaryEnd = binaryChunk.byteOffset + binaryChunk.byteLength;
  if (count < 0 || requiredEnd > binaryEnd) {
    throw new Error(`GLB accessor ${accessorIndex} 数据越界。`);
  }

  let array;
  if (stride === packedStride && byteOffset % component.bytes === 0) {
    const source = new component.ArrayType(binaryChunk.buffer, byteOffset, count * itemSize);
    array = new component.ArrayType(source);
  } else {
    array = new component.ArrayType(count * itemSize);
    const dataView = new DataView(binaryChunk.buffer);
    for (let row = 0; row < count; row += 1) {
      const rowOffset = byteOffset + row * stride;
      for (let column = 0; column < itemSize; column += 1) {
        const componentOffset = rowOffset + column * component.bytes;
        array[row * itemSize + column] = dataView[component.getter](componentOffset, true);
      }
    }
  }

  return {
    array,
    itemSize,
    count,
    normalized: Boolean(accessor.normalized),
    componentType: accessor.componentType,
    type: accessor.type,
    min: Array.isArray(accessor.min) ? [...accessor.min] : null,
    max: Array.isArray(accessor.max) ? [...accessor.max] : null,
  };
}
