import { computePoseWorldPositions, computeRestWorldPositions } from './skeleton-model.js';
import { loadGlbMesh } from './glb-geometry.js';

const EPSILON = 1e-8;
const REST_EPSILON = 1e-7;
const WEIGHT_CHUNK_SIZE = 1024;
const SMPL_ASSET_URL = new URL('../assets/smpl/smpl-male-surface.glb', import.meta.url).href;

const SMPL_JOINT_IDS = Object.freeze([
  'hips',
  'leftUpperLeg', 'rightUpperLeg',
  'spine',
  'leftLowerLeg', 'rightLowerLeg',
  'chest',
  'leftFoot', 'rightFoot',
  'upperChest',
  'leftToes', 'rightToes',
  'neck',
  'leftShoulder', 'rightShoulder',
  'head',
  'leftUpperArm', 'rightUpperArm',
  'leftLowerArm', 'rightLowerArm',
  'leftHand', 'rightHand',
  'leftHandEnd', 'rightHandEnd',
]);

const PRIMARY_CHILD = Object.freeze({
  hips: 'spine',
  spine: 'chest',
  chest: 'upperChest',
  upperChest: 'neck',
  neck: 'head',
  head: 'headTop',
  leftShoulder: 'leftUpperArm',
  leftUpperArm: 'leftLowerArm',
  leftLowerArm: 'leftHand',
  leftHand: 'leftHandEnd',
  rightShoulder: 'rightUpperArm',
  rightUpperArm: 'rightLowerArm',
  rightLowerArm: 'rightHand',
  rightHand: 'rightHandEnd',
  leftUpperLeg: 'leftLowerLeg',
  leftLowerLeg: 'leftFoot',
  leftFoot: 'leftToes',
  leftToes: 'leftToesEnd',
  rightUpperLeg: 'rightLowerLeg',
  rightLowerLeg: 'rightFoot',
  rightFoot: 'rightToes',
  rightToes: 'rightToesEnd',
});

const PARENT_FALLBACK = Object.freeze({
  leftHandEnd: 'leftHand',
  rightHandEnd: 'rightHand',
  leftToes: 'leftFoot',
  rightToes: 'rightFoot',
  head: 'neck',
  neck: 'upperChest',
});

/**
 * Creates one detailed human mesh. V8.4 contains no procedural body shell,
 * hidden selection body, fallback skin mesh, or yellow surface highlight.
 * The imported mesh is used for rendering, direct ray picking, and deformation.
 */
export async function createSmplSkinLayer(THREE, scene, definition, callbacks = {}) {
  const layer = new SingleSmplHumanSurfaceLayer(THREE, scene, callbacks);
  layer.init(definition);
  return layer;
}

class SingleSmplHumanSurfaceLayer {
  constructor(THREE, scene, callbacks = {}) {
    this.THREE = THREE;
    this.scene = scene;
    this.callbacks = callbacks;
    this.visible = true;
    this.opacity = 1;
    this.mode = 'solid';
    this.source = 'detail';
    this.disposed = false;
    this.weightsReady = false;
    this.lastDefinition = null;
    this.lastSurfaceState = null;
    this.jointIds = [];
    this.boneIndexById = new Map();
    this.restPoints = new Map();
    this.skinIndices = null;
    this.skinWeights = null;
    this.restPositions = null;
    this.restNormals = null;
    this.deformedPositions = null;
    this.deformedNormals = null;
    this.dualQuaternionData = null;
    this.lastPoseValues = null;
    this.detailPromise = null;
    this.temp = {
      a: new THREE.Vector3(),
      b: new THREE.Vector3(),
    };
  }

  init(definition) {
    this.lastDefinition = definition;
    this.group = new this.THREE.Group();
    this.group.name = 'SMPLSingleDetailedHumanSurface';
    this.group.renderOrder = 0;
    this.scene.add(this.group);
    this.setVisible(this.visible);

    this.emitState(
      'loading',
      '正在读取唯一人物表皮',
      '视口中只保留精细 SMPL 人体网格，加载期间继续显示骨架',
    );

    this.detailPromise = this.loadDetailedSurface(definition)
      .catch((error) => {
        if (this.disposed) return null;
        console.error('Detailed human surface failed to initialize.', error);
        this.emitState(
          'error',
          '精细人物表皮加载失败',
          error instanceof Error ? error.message : String(error),
        );
        return null;
      })
      .finally(() => {
        this.detailPromise = null;
      });
  }

  async loadDetailedSurface(definition) {
    const meshData = await loadGlbMesh(SMPL_ASSET_URL);
    if (this.disposed) return null;

    const geometry = createThreeGeometry(this.THREE, meshData);
    this.restPositions = new Float32Array(geometry.attributes.position.array);
    this.restNormals = new Float32Array(geometry.attributes.normal.array);
    this.deformedPositions = geometry.attributes.position.array;
    this.deformedNormals = geometry.attributes.normal.array;

    this.material = createReliableSurfaceMaterial(this.THREE);
    this.mesh = new this.THREE.Mesh(geometry, this.material);
    this.mesh.name = 'MeshcapadeSampleHumanSurfaceSingleMesh';
    this.mesh.castShadow = false;
    this.mesh.receiveShadow = false;
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 0;
    this.mesh.userData.surfaceEngine = 'CPU region-isolated adjacency-smoothed four-influence DQS';
    this.mesh.userData.surfacePickSource = 'detailed-smpl-mesh';
    this.group.add(this.mesh);

    this.setMode(this.mode);
    this.setOpacity(this.opacity);
    this.setVisible(this.visible);

    const vertexCount = geometry.attributes.position.count;
    const triangleCount = geometry.index
      ? Math.floor(geometry.index.count / 3)
      : Math.floor(vertexCount / 3);

    this.emitState(
      'preview',
      '唯一精细人物表皮已显示',
      `${vertexCount.toLocaleString()} 顶点 · 正在建立分区蒙皮权重`,
    );

    await yieldToBrowser();
    if (this.disposed) return null;

    this.buildSkinRig(definition);
    await this.generateSkinWeightsAsync(geometry);
    if (this.disposed) return null;

    this.weightsReady = true;
    this.refresh(this.lastDefinition ?? definition, null, { force: true });
    this.emitState(
      'ready',
      '唯一精细人物表皮已绑定',
      `${vertexCount.toLocaleString()} 顶点 · ${triangleCount.toLocaleString()} 三角形 · 分区权重与双四元数变形`,
    );
    return this;
  }

  buildSkinRig(definition) {
    const rest = computeRestWorldPositions(definition);
    const byId = new Map(definition.joints.map((joint) => [joint.id, joint]));
    this.jointIds = SMPL_JOINT_IDS.filter((id) => byId.has(id) && rest.has(id));
    if (this.jointIds.length !== 24) {
      throw new Error(`需要完整的 SMPL 24 关节映射，当前只有 ${this.jointIds.length} 个。`);
    }

    this.boneIndexById.clear();
    this.restPoints.clear();
    this.jointIds.forEach((id, index) => {
      const source = rest.get(id);
      this.restPoints.set(id, new this.THREE.Vector3(source.x, source.y, source.z));
      this.boneIndexById.set(id, index);
    });

    this.dualQuaternionData = new Float32Array(this.jointIds.length * 8);
    this.lastPoseValues = new Float64Array(this.jointIds.length * 3);
    this.lastPoseValues.fill(Number.NaN);
  }

  async generateSkinWeightsAsync(geometry) {
    const positions = geometry.attributes.position.array;
    const vertexCount = geometry.attributes.position.count;
    const skinIndices = new Uint16Array(vertexCount * 4);
    const skinWeights = new Float32Array(vertexCount * 4);
    const chains = createWeightChains(this.restPoints, this.boneIndexById);
    const influence = new Float64Array(this.jointIds.length);
    const touched = new Uint8Array(this.jointIds.length);

    for (let vertexIndex = 0; vertexIndex < vertexCount; vertexIndex += 1) {
      const offset = vertexIndex * 3;
      const x = positions[offset];
      const y = positions[offset + 1];
      const z = positions[offset + 2];
      influence.fill(0);
      touched.fill(0);

      const candidates = selectWeightCandidates(x, y, z, chains);
      for (const candidate of candidates) {
        const result = evaluateChainNumeric(x, y, z, candidate.chain);
        result.score *= candidate.multiplier;
        if (result.score > 1e-8) addChainInfluencesNumeric(influence, touched, result);
      }

      if (!hasTouched(touched)) {
        const fallbackId = fallbackJointForVertex(x, y, z);
        const fallbackIndex = this.boneIndexById.get(fallbackId)
          ?? this.boneIndexById.get('hips')
          ?? 0;
        influence[fallbackIndex] = 1;
        touched[fallbackIndex] = 1;
      }

      writeFourStrongestInfluences(
        influence,
        touched,
        skinIndices,
        skinWeights,
        vertexIndex,
        this.boneIndexById.get('hips') ?? 0,
      );

      if ((vertexIndex + 1) % WEIGHT_CHUNK_SIZE === 0) {
        const progress = Math.round(((vertexIndex + 1) / vertexCount) * 100);
        this.emitState(
          'binding',
          '唯一人物表皮正在绑定',
          `分区四关节权重 ${progress}%`,
        );
        await yieldToBrowser();
        if (this.disposed) return;
      }
    }

    smoothSkinWeights(
      geometry,
      skinIndices,
      skinWeights,
      this.jointIds.length,
      { passes: 3, alpha: 0.38 },
    );

    this.skinIndices = skinIndices;
    this.skinWeights = skinWeights;
  }

  refresh(definition, _interaction = null, { force = false } = {}) {
    this.lastDefinition = definition;
    if (!this.mesh || !this.weightsReady || !this.skinIndices || !this.skinWeights) return;

    const pose = computePoseWorldPositions(definition);
    const posePoints = new Map();
    let poseChanged = force;
    for (let index = 0; index < this.jointIds.length; index += 1) {
      const id = this.jointIds[index];
      const point = pose.get(id);
      if (!point) continue;
      posePoints.set(id, new this.THREE.Vector3(point.x, point.y, point.z));
      const offset = index * 3;
      if (
        this.lastPoseValues[offset] !== point.x
        || this.lastPoseValues[offset + 1] !== point.y
        || this.lastPoseValues[offset + 2] !== point.z
      ) {
        poseChanged = true;
        this.lastPoseValues[offset] = point.x;
        this.lastPoseValues[offset + 1] = point.y;
        this.lastPoseValues[offset + 2] = point.z;
      }
    }
    if (!poseChanged) return;

    if (isRestPose(this.restPoints, posePoints, this.jointIds, REST_EPSILON)) {
      this.deformedPositions.set(this.restPositions);
      this.deformedNormals.set(this.restNormals);
      this.mesh.userData.bindPoseProtected = true;
    } else {
      this.updateDualQuaternionData(posePoints);
      deformSurfaceDqs(
        this.restPositions,
        this.restNormals,
        this.deformedPositions,
        this.deformedNormals,
        this.skinIndices,
        this.skinWeights,
        this.dualQuaternionData,
      );
      this.mesh.userData.bindPoseProtected = false;
    }

    const positionAttribute = this.mesh.geometry.attributes.position;
    const normalAttribute = this.mesh.geometry.attributes.normal;
    positionAttribute.needsUpdate = true;
    normalAttribute.needsUpdate = true;
    this.mesh.geometry.computeBoundingBox();
    this.mesh.geometry.computeBoundingSphere();
  }

  updateDualQuaternionData(posePoints) {
    for (let index = 0; index < this.jointIds.length; index += 1) {
      const id = this.jointIds[index];
      const restPoint = this.restPoints.get(id);
      const currentPoint = posePoints.get(id);
      if (!restPoint || !currentPoint) continue;

      const q = this.calculateJointRotation(id, posePoints).normalize();
      const rotated = rotatePointByQuaternion(restPoint.x, restPoint.y, restPoint.z, q.x, q.y, q.z, q.w);
      const tx = currentPoint.x - rotated[0];
      const ty = currentPoint.y - rotated[1];
      const tz = currentPoint.z - rotated[2];
      const dual = translationTimesQuaternion(tx, ty, tz, q.x, q.y, q.z, q.w);
      const offset = index * 8;
      this.dualQuaternionData[offset] = q.x;
      this.dualQuaternionData[offset + 1] = q.y;
      this.dualQuaternionData[offset + 2] = q.z;
      this.dualQuaternionData[offset + 3] = q.w;
      this.dualQuaternionData[offset + 4] = dual[0];
      this.dualQuaternionData[offset + 5] = dual[1];
      this.dualQuaternionData[offset + 6] = dual[2];
      this.dualQuaternionData[offset + 7] = dual[3];
    }
  }

  calculateJointRotation(id, posePoints) {
    const THREE = this.THREE;
    if (id === 'hips') {
      return bodyFrameRotation(
        THREE, this.restPoints, posePoints,
        'leftUpperLeg', 'rightUpperLeg', 'hips', 'upperChest',
      );
    }
    if (id === 'upperChest') {
      return bodyFrameRotation(
        THREE, this.restPoints, posePoints,
        'leftUpperArm', 'rightUpperArm', 'upperChest', 'neck',
      );
    }

    const restPoint = this.restPoints.get(id);
    const currentPoint = posePoints.get(id);
    const childId = PRIMARY_CHILD[id];
    if (childId && restPoint && currentPoint) {
      const restChild = this.restPoints.get(childId);
      const currentChild = posePoints.get(childId);
      if (restChild && currentChild) {
        const restDirection = this.temp.a.copy(restChild).sub(restPoint);
        const currentDirection = this.temp.b.copy(currentChild).sub(currentPoint);
        if (restDirection.lengthSq() > EPSILON && currentDirection.lengthSq() > EPSILON) {
          return new THREE.Quaternion().setFromUnitVectors(
            restDirection.normalize(),
            currentDirection.normalize(),
          );
        }
      }
    }

    const parentId = PARENT_FALLBACK[id];
    if (parentId && restPoint && currentPoint) {
      const restParent = this.restPoints.get(parentId);
      const currentParent = posePoints.get(parentId);
      if (restParent && currentParent) {
        const restDirection = this.temp.a.copy(restPoint).sub(restParent);
        const currentDirection = this.temp.b.copy(currentPoint).sub(currentParent);
        if (restDirection.lengthSq() > EPSILON && currentDirection.lengthSq() > EPSILON) {
          return new THREE.Quaternion().setFromUnitVectors(
            restDirection.normalize(),
            currentDirection.normalize(),
          );
        }
      }
    }
    return new THREE.Quaternion();
  }

  setVisible(visible) {
    this.visible = Boolean(visible);
    if (!this.group) return;
    this.group.visible = this.visible;
    const attached = this.group.parent === this.scene;
    if (this.visible && !attached) this.scene.add(this.group);
    if (!this.visible && attached) this.scene.remove(this.group);
  }

  setSource(_source) {
    this.source = 'detail';
  }

  getActiveSource() {
    return this.visible ? 'detail' : 'hidden';
  }

  setOpacity(value) {
    this.opacity = clamp(Number(value), 0.2, 1);
    if (!this.material) return;
    this.material.opacity = this.opacity;
    this.material.transparent = this.mode !== 'solid' || this.opacity < 0.999;
    this.material.depthWrite = this.mode === 'solid' || this.opacity >= 0.78;
    this.material.needsUpdate = true;
  }

  setMode(mode) {
    this.mode = ['solid', 'translucent', 'wireframe'].includes(mode) ? mode : 'solid';
    if (!this.material) return;
    this.material.wireframe = this.mode === 'wireframe';
    this.material.transparent = this.mode !== 'solid' || this.opacity < 0.999;
    this.material.opacity = this.mode === 'solid' ? 1 : this.opacity;
    this.material.depthWrite = this.mode === 'solid' || this.opacity >= 0.78;
    this.material.needsUpdate = true;
  }

  getPickTargets() {
    if (!this.visible || !this.mesh) return [];
    return [this.mesh];
  }

  resolvePick(intersection) {
    if (!intersection || intersection.object !== this.mesh) return null;
    const jointIndex = this.resolveDominantJointIndex(intersection);
    if (!Number.isInteger(jointIndex)) return null;
    const jointId = this.jointIds[jointIndex];
    if (!jointId) return null;
    return {
      kind: 'joint',
      jointId,
      point: intersection.point?.clone?.() ?? intersection.point,
      distance: intersection.distance,
      surfacePart: 'detailed-smpl-mesh',
    };
  }

  resolveDominantJointIndex(intersection) {
    if (!this.skinIndices || !this.skinWeights) {
      return this.nearestJointIndex(intersection.point);
    }
    const vertices = faceVertexIndices(this.mesh.geometry, intersection);
    if (!vertices.length) return this.nearestJointIndex(intersection.point);
    const scores = new Float64Array(this.jointIds.length);
    for (const vertexIndex of vertices) {
      const offset = vertexIndex * 4;
      for (let slot = 0; slot < 4; slot += 1) {
        const index = this.skinIndices[offset + slot];
        scores[index] += this.skinWeights[offset + slot];
      }
    }
    let bestIndex = 0;
    let bestScore = -1;
    for (let index = 0; index < scores.length; index += 1) {
      if (scores[index] > bestScore) {
        bestScore = scores[index];
        bestIndex = index;
      }
    }
    return bestIndex;
  }

  nearestJointIndex(point) {
    if (!point) return this.boneIndexById.get('hips') ?? 0;
    const pose = this.lastDefinition ? computePoseWorldPositions(this.lastDefinition) : null;
    let bestIndex = this.boneIndexById.get('hips') ?? 0;
    let bestDistance = Infinity;
    for (let index = 0; index < this.jointIds.length; index += 1) {
      const candidate = pose?.get(this.jointIds[index]) ?? this.restPoints.get(this.jointIds[index]);
      if (!candidate) continue;
      const dx = point.x - candidate.x;
      const dy = point.y - candidate.y;
      const dz = point.z - candidate.z;
      const distance = dx * dx + dy * dy + dz * dz;
      if (distance < bestDistance) {
        bestDistance = distance;
        bestIndex = index;
      }
    }
    return bestIndex;
  }

  getDiagnostics() {
    const geometry = this.mesh?.geometry;
    const position = geometry?.attributes?.position;
    const attached = this.group?.parent === this.scene;
    const renderableCount = this.visible && attached && this.mesh?.visible !== false ? 1 : 0;
    return {
      type: 'single-smpl-human-surface',
      state: this.lastSurfaceState?.state ?? 'loading',
      visible: this.visible,
      opacity: this.opacity,
      mode: this.mode,
      requestedSource: 'detail',
      activeSource: this.getActiveSource(),
      singleVisibleSurface: renderableCount <= 1,
      renderableSurfaceCount: renderableCount,
      proceduralSurfacePresent: false,
      attachedToScene: attached,
      meshVisible: Boolean(this.mesh?.visible !== false && this.visible),
      weightsReady: this.weightsReady,
      vertexCount: position?.count ?? 0,
      triangleCount: geometry?.index ? Math.floor(geometry.index.count / 3) : 0,
      pickSource: 'detailed-smpl-mesh',
      pickable: this.getPickTargets().length,
      deformation: 'CPU region-isolated adjacency-smoothed four-influence dual-quaternion skinning',
      bindPoseProtected: Boolean(this.mesh?.userData?.bindPoseProtected),
      assetUrl: SMPL_ASSET_URL,
    };
  }

  emitState(state, label, detail) {
    this.lastSurfaceState = { state, label, detail };
    this.callbacks.onSurfaceState?.(this.lastSurfaceState);
  }

  dispose() {
    this.disposed = true;
    if (this.group) this.scene.remove(this.group);
    this.mesh?.geometry?.dispose?.();
    this.material?.dispose?.();
    this.skinIndices = null;
    this.skinWeights = null;
    this.dualQuaternionData = null;
  }
}

function createReliableSurfaceMaterial(THREE) {
  return new THREE.MeshStandardMaterial({
    color: 0xd6a68f,
    roughness: 0.78,
    metalness: 0,
    transparent: false,
    opacity: 1,
    depthTest: true,
    depthWrite: true,
    side: THREE.DoubleSide,
    vertexColors: false,
  });
}

function createThreeGeometry(THREE, meshData) {
  if (meshData.mode !== 4) throw new Error(`人体表皮网格模式 ${meshData.mode} 暂不支持。`);
  const geometry = new THREE.BufferGeometry();
  const sourcePosition = meshData.attributes.position;
  const sourceNormal = meshData.attributes.normal;
  geometry.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(sourcePosition.array), 3));
  if (sourceNormal) {
    geometry.setAttribute('normal', new THREE.Float32BufferAttribute(new Float32Array(sourceNormal.array), 3));
  } else {
    geometry.computeVertexNormals();
  }
  if (meshData.index) {
    geometry.setIndex(new THREE.BufferAttribute(new meshData.index.array.constructor(meshData.index.array), 1, false));
  }
  geometry.attributes.position.setUsage?.(THREE.DynamicDrawUsage);
  geometry.attributes.normal.setUsage?.(THREE.DynamicDrawUsage);
  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();
  return geometry;
}

function createWeightChains(points, boneIndexById) {
  const pointArray = (ids) => ids.map((id) => {
    const point = points.get(id);
    return point ? [point.x, point.y, point.z] : null;
  });
  const chain = (name, ids, radii) => ({
    name,
    ids,
    indices: ids.map((id) => boneIndexById.get(id)),
    radii,
    points: pointArray(ids),
  });
  return [
    chain('torso', ['hips', 'spine', 'chest', 'upperChest', 'neck', 'head'], [0.23, 0.23, 0.24, 0.17, 0.145]),
    chain('leftArm', ['leftShoulder', 'leftUpperArm', 'leftLowerArm', 'leftHand', 'leftHandEnd'], [0.115, 0.095, 0.068, 0.055]),
    chain('rightArm', ['rightShoulder', 'rightUpperArm', 'rightLowerArm', 'rightHand', 'rightHandEnd'], [0.115, 0.095, 0.068, 0.055]),
    chain('leftLeg', ['leftUpperLeg', 'leftLowerLeg', 'leftFoot', 'leftToes'], [0.145, 0.115, 0.082]),
    chain('rightLeg', ['rightUpperLeg', 'rightLowerLeg', 'rightFoot', 'rightToes'], [0.145, 0.115, 0.082]),
  ].filter((item) => item.points.every(Boolean) && item.indices.every(Number.isInteger));
}

/** Returns only anatomically compatible chains for one bind-pose vertex. */
function selectWeightCandidates(x, y, z, chains) {
  const byName = new Map(chains.map((chain) => [chain.name, chain]));
  const candidates = [];
  const absX = Math.abs(x);
  const side = x < 0 ? 'left' : 'right';

  if (y >= 1.50) {
    pushCandidate(candidates, byName.get('torso'), 1);
    return candidates;
  }

  const armBoundary = armBoundaryAtHeight(y);
  const armMask = smoothstep(armBoundary - 0.035, armBoundary + 0.035, absX)
    * smoothstep(0.72, 0.82, y)
    * (1 - smoothstep(1.48, 1.55, y));
  const shoulderTransition = smoothstep(1.20, 1.30, y)
    * (1 - smoothstep(1.47, 1.53, y))
    * smoothstep(0.145, 0.205, absX);

  if (y >= 0.74) {
    const torsoMultiplier = Math.max(0.02, 1 - armMask * 0.96);
    pushCandidate(candidates, byName.get('torso'), torsoMultiplier);
    pushCandidate(candidates, byName.get(`${side}Arm`), Math.max(armMask, shoulderTransition * 0.62));
    if (absX < 0.025 && shoulderTransition < 0.05) {
      pushCandidate(candidates, byName.get(side === 'left' ? 'rightArm' : 'leftArm'), 0.002);
    }
  }

  // Lower-body candidates are limited to the pelvis and leg corridor.
  // A-pose hands sit near y=0.83 and x=+-0.39, so an unbounded leg mask
  // would mix hand vertices with the hip and thigh and create long spikes.
  const legBoundary = lowerBodyBoundaryAtHeight(y);
  const insideLegCorridor = absX <= legBoundary;
  const legMask = insideLegCorridor
    ? (1 - smoothstep(0.91, 1.04, y)) * smoothstep(0.015, 0.075, absX)
    : 0;
  if ((legMask > 0.001 || y < 0.76) && (insideLegCorridor || y < 0.70)) {
    pushCandidate(candidates, byName.get(`${side}Leg`), Math.max(legMask, y < 0.76 ? 1 : 0));
    if (y > 0.78) pushCandidate(candidates, byName.get('torso'), smoothstep(0.78, 0.96, y) * 0.42);
  }

  // Forefoot vertices can cross the sagittal plane. Keep them on the nearest
  // leg using lateral sign and the forward Z coordinate.
  if (y < 0.20 && z > 0.035) {
    candidates.length = 0;
    pushCandidate(candidates, byName.get(`${side}Leg`), 1);
  }

  return mergeCandidates(candidates);
}

function pushCandidate(target, chain, multiplier) {
  if (chain && multiplier > 1e-6) target.push({ chain, multiplier });
}

function mergeCandidates(candidates) {
  const merged = new Map();
  for (const item of candidates) {
    const previous = merged.get(item.chain.name);
    if (!previous || item.multiplier > previous.multiplier) merged.set(item.chain.name, item);
  }
  return [...merged.values()];
}

function armBoundaryAtHeight(y) {
  if (y >= 1.34) return 0.18;
  if (y <= 0.82) return 0.26;
  return 0.18 + (1.34 - y) * (0.08 / 0.52);
}

function lowerBodyBoundaryAtHeight(y) {
  if (y >= 1.02) return 0.16;
  if (y <= 0.70) return 0.26;
  return 0.16 + (1.02 - y) * (0.10 / 0.32);
}

function fallbackJointForVertex(x, y, z) {
  if (y > 1.52) return 'head';
  if (y > 1.40) return 'neck';
  if (y > 1.02) return 'upperChest';
  if (y > 0.78) return 'hips';
  const side = x < 0 ? 'left' : 'right';
  if (y > 0.30) return `${side}UpperLeg`;
  if (y > 0.12) return `${side}LowerLeg`;
  return z > 0.05 ? `${side}Toes` : `${side}Foot`;
}

function evaluateChainNumeric(x, y, z, chain) {
  let bestNormalizedDistance = Infinity;
  let bestSegment = 0;
  let bestT = 0;
  let bestRadius = 0.1;
  for (let index = 0; index < chain.points.length - 1; index += 1) {
    const a = chain.points[index];
    const b = chain.points[index + 1];
    const abx = b[0] - a[0];
    const aby = b[1] - a[1];
    const abz = b[2] - a[2];
    const apx = x - a[0];
    const apy = y - a[1];
    const apz = z - a[2];
    const lengthSq = abx * abx + aby * aby + abz * abz;
    const t = lengthSq > EPSILON
      ? clamp((apx * abx + apy * aby + apz * abz) / lengthSq, 0, 1)
      : 0;
    const dx = apx - abx * t;
    const dy = apy - aby * t;
    const dz = apz - abz * t;
    const radius = chain.radii[index] ?? chain.radii.at(-1) ?? 0.1;
    const normalizedDistance = Math.sqrt(dx * dx + dy * dy + dz * dz) / radius;
    if (normalizedDistance < bestNormalizedDistance) {
      bestNormalizedDistance = normalizedDistance;
      bestSegment = index;
      bestT = t;
      bestRadius = radius;
    }
  }
  const score = Math.exp(-0.5 * bestNormalizedDistance * bestNormalizedDistance) * (0.75 + bestRadius);
  return { chain, score, segmentIndex: bestSegment, t: bestT };
}

function addChainInfluencesNumeric(target, touched, result) {
  const { chain, segmentIndex, t, score } = result;
  const aIndex = chain.indices[segmentIndex];
  const bIndex = chain.indices[segmentIndex + 1];
  addWeightNumeric(target, touched, aIndex, score * (1 - t));
  addWeightNumeric(target, touched, bIndex, score * t);
  const previousIndex = chain.indices[segmentIndex - 1];
  const nextIndex = chain.indices[segmentIndex + 2];
  if (Number.isInteger(previousIndex)) addWeightNumeric(target, touched, previousIndex, score * 0.08 * (1 - t));
  if (Number.isInteger(nextIndex)) addWeightNumeric(target, touched, nextIndex, score * 0.08 * t);
}

function addWeightNumeric(target, touched, index, value) {
  if (!Number.isInteger(index) || value <= 0) return;
  target[index] += value;
  touched[index] = 1;
}

/**
 * Smooth sparse weights over the real triangle adjacency graph. Neighbouring
 * shoulder and hip vertices then receive compatible bone mixtures, reducing
 * spikes and hard seams without adding another surface layer.
 */
function smoothSkinWeights(
  geometry,
  skinIndices,
  skinWeights,
  jointCount,
  { passes = 2, alpha = 0.32 } = {},
) {
  const triangleIndices = geometry?.index?.array;
  const position = geometry?.attributes?.position;
  if (!triangleIndices || !position?.count || passes <= 0 || alpha <= 0) return;

  const vertexCount = position.count;
  const clampedAlpha = clamp(alpha, 0, 0.8);
  const ownScale = 1 - clampedAlpha;
  const neighborAccum = new Float32Array(vertexCount * jointCount);
  const neighborCount = new Uint16Array(vertexCount);
  const nextIndices = new Uint16Array(skinIndices.length);
  const nextWeights = new Float32Array(skinWeights.length);
  const influence = new Float64Array(jointCount);
  const touched = new Uint8Array(jointCount);

  const accumulateNeighbor = (targetVertex, sourceVertex) => {
    const targetBase = targetVertex * jointCount;
    const sourceBase = sourceVertex * 4;
    for (let slot = 0; slot < 4; slot += 1) {
      const weight = skinWeights[sourceBase + slot];
      if (weight <= 0) continue;
      const jointIndex = skinIndices[sourceBase + slot];
      neighborAccum[targetBase + jointIndex] += weight;
    }
    neighborCount[targetVertex] += 1;
  };

  for (let pass = 0; pass < passes; pass += 1) {
    neighborAccum.fill(0);
    neighborCount.fill(0);

    for (let offset = 0; offset < triangleIndices.length; offset += 3) {
      const a = triangleIndices[offset];
      const b = triangleIndices[offset + 1];
      const c = triangleIndices[offset + 2];
      accumulateNeighbor(a, b); accumulateNeighbor(a, c);
      accumulateNeighbor(b, a); accumulateNeighbor(b, c);
      accumulateNeighbor(c, a); accumulateNeighbor(c, b);
    }

    for (let vertexIndex = 0; vertexIndex < vertexCount; vertexIndex += 1) {
      influence.fill(0);
      touched.fill(0);
      const sparseOffset = vertexIndex * 4;
      for (let slot = 0; slot < 4; slot += 1) {
        const weight = skinWeights[sparseOffset + slot] * ownScale;
        if (weight <= 0) continue;
        const jointIndex = skinIndices[sparseOffset + slot];
        influence[jointIndex] += weight;
        touched[jointIndex] = 1;
      }

      const count = neighborCount[vertexIndex];
      if (count > 0) {
        const denseOffset = vertexIndex * jointCount;
        const scale = clampedAlpha / count;
        for (let jointIndex = 0; jointIndex < jointCount; jointIndex += 1) {
          const weight = neighborAccum[denseOffset + jointIndex] * scale;
          if (weight <= 0) continue;
          influence[jointIndex] += weight;
          touched[jointIndex] = 1;
        }
      }

      writeFourStrongestInfluences(
        influence,
        touched,
        nextIndices,
        nextWeights,
        vertexIndex,
        skinIndices[sparseOffset] ?? 0,
      );
    }

    skinIndices.set(nextIndices);
    skinWeights.set(nextWeights);
  }
}

function hasTouched(touched) {
  for (let index = 0; index < touched.length; index += 1) if (touched[index]) return true;
  return false;
}

function writeFourStrongestInfluences(influence, touched, skinIndices, skinWeights, vertexIndex, fallbackIndex) {
  const bestIndices = [fallbackIndex, fallbackIndex, fallbackIndex, fallbackIndex];
  const bestWeights = [0, 0, 0, 0];
  for (let index = 0; index < influence.length; index += 1) {
    if (!touched[index]) continue;
    const value = influence[index];
    for (let slot = 0; slot < 4; slot += 1) {
      if (value <= bestWeights[slot]) continue;
      for (let shift = 3; shift > slot; shift -= 1) {
        bestWeights[shift] = bestWeights[shift - 1];
        bestIndices[shift] = bestIndices[shift - 1];
      }
      bestWeights[slot] = value;
      bestIndices[slot] = index;
      break;
    }
  }
  const total = bestWeights[0] + bestWeights[1] + bestWeights[2] + bestWeights[3] || 1;
  const offset = vertexIndex * 4;
  for (let slot = 0; slot < 4; slot += 1) {
    skinIndices[offset + slot] = bestIndices[slot];
    skinWeights[offset + slot] = bestWeights[slot] / total;
  }
}

/** Dual quaternion deformation keeps shoulder and hip volume better than LBS. */
function deformSurfaceDqs(
  restPositions,
  restNormals,
  outputPositions,
  outputNormals,
  skinIndices,
  skinWeights,
  dualQuaternions,
) {
  const vertexCount = restPositions.length / 3;
  for (let vertexIndex = 0; vertexIndex < vertexCount; vertexIndex += 1) {
    const pOffset = vertexIndex * 3;
    const sOffset = vertexIndex * 4;
    const firstJoint = skinIndices[sOffset];
    const firstOffset = firstJoint * 8;
    const refX = dualQuaternions[firstOffset];
    const refY = dualQuaternions[firstOffset + 1];
    const refZ = dualQuaternions[firstOffset + 2];
    const refW = dualQuaternions[firstOffset + 3];

    let rx = 0; let ry = 0; let rz = 0; let rw = 0;
    let dx = 0; let dy = 0; let dz = 0; let dw = 0;
    for (let slot = 0; slot < 4; slot += 1) {
      const weight = skinWeights[sOffset + slot];
      if (weight <= 0) continue;
      const qOffset = skinIndices[sOffset + slot] * 8;
      let qx = dualQuaternions[qOffset];
      let qy = dualQuaternions[qOffset + 1];
      let qz = dualQuaternions[qOffset + 2];
      let qw = dualQuaternions[qOffset + 3];
      let qdx = dualQuaternions[qOffset + 4];
      let qdy = dualQuaternions[qOffset + 5];
      let qdz = dualQuaternions[qOffset + 6];
      let qdw = dualQuaternions[qOffset + 7];
      const sign = qx * refX + qy * refY + qz * refZ + qw * refW < 0 ? -1 : 1;
      qx *= sign; qy *= sign; qz *= sign; qw *= sign;
      qdx *= sign; qdy *= sign; qdz *= sign; qdw *= sign;
      rx += weight * qx; ry += weight * qy; rz += weight * qz; rw += weight * qw;
      dx += weight * qdx; dy += weight * qdy; dz += weight * qdz; dw += weight * qdw;
    }

    const norm = Math.sqrt(rx * rx + ry * ry + rz * rz + rw * rw) || 1;
    rx /= norm; ry /= norm; rz /= norm; rw /= norm;
    dx /= norm; dy /= norm; dz /= norm; dw /= norm;
    const dualDot = rx * dx + ry * dy + rz * dz + rw * dw;
    dx -= rx * dualDot; dy -= ry * dualDot; dz -= rz * dualDot; dw -= rw * dualDot;

    const translation = dualQuaternionTranslation(rx, ry, rz, rw, dx, dy, dz, dw);
    const position = rotatePointByQuaternion(
      restPositions[pOffset], restPositions[pOffset + 1], restPositions[pOffset + 2],
      rx, ry, rz, rw,
    );
    outputPositions[pOffset] = position[0] + translation[0];
    outputPositions[pOffset + 1] = position[1] + translation[1];
    outputPositions[pOffset + 2] = position[2] + translation[2];

    const normal = rotatePointByQuaternion(
      restNormals[pOffset], restNormals[pOffset + 1], restNormals[pOffset + 2],
      rx, ry, rz, rw,
    );
    const normalLength = Math.hypot(normal[0], normal[1], normal[2]) || 1;
    outputNormals[pOffset] = normal[0] / normalLength;
    outputNormals[pOffset + 1] = normal[1] / normalLength;
    outputNormals[pOffset + 2] = normal[2] / normalLength;
  }
}

function translationTimesQuaternion(tx, ty, tz, qx, qy, qz, qw) {
  return [
    0.5 * (tx * qw + ty * qz - tz * qy),
    0.5 * (ty * qw + tz * qx - tx * qz),
    0.5 * (tz * qw + tx * qy - ty * qx),
    -0.5 * (tx * qx + ty * qy + tz * qz),
  ];
}

function dualQuaternionTranslation(rx, ry, rz, rw, dx, dy, dz, dw) {
  return [
    2 * (-dw * rx + dx * rw - dy * rz + dz * ry),
    2 * (-dw * ry + dx * rz + dy * rw - dz * rx),
    2 * (-dw * rz - dx * ry + dy * rx + dz * rw),
  ];
}

function rotatePointByQuaternion(px, py, pz, qx, qy, qz, qw) {
  const tx = 2 * (qy * pz - qz * py);
  const ty = 2 * (qz * px - qx * pz);
  const tz = 2 * (qx * py - qy * px);
  return [
    px + qw * tx + (qy * tz - qz * ty),
    py + qw * ty + (qz * tx - qx * tz),
    pz + qw * tz + (qx * ty - qy * tx),
  ];
}

function isRestPose(restPoints, posePoints, jointIds, epsilon = REST_EPSILON) {
  for (const id of jointIds) {
    const rest = restPoints.get(id);
    const pose = posePoints.get(id);
    if (!rest || !pose) return false;
    if (
      Math.abs(rest.x - pose.x) > epsilon
      || Math.abs(rest.y - pose.y) > epsilon
      || Math.abs(rest.z - pose.z) > epsilon
    ) return false;
  }
  return true;
}

function bodyFrameRotation(THREE, restPoints, posePoints, leftId, rightId, originId, upId) {
  const restBasis = makeBodyBasis(THREE, restPoints, leftId, rightId, originId, upId);
  const currentBasis = makeBodyBasis(THREE, posePoints, leftId, rightId, originId, upId);
  const restQuaternion = new THREE.Quaternion().setFromRotationMatrix(restBasis);
  const currentQuaternion = new THREE.Quaternion().setFromRotationMatrix(currentBasis);
  return currentQuaternion.multiply(restQuaternion.invert()).normalize();
}

function makeBodyBasis(THREE, points, leftId, rightId, originId, upId) {
  const left = points.get(leftId);
  const rightPoint = points.get(rightId);
  const origin = points.get(originId);
  const upPoint = points.get(upId);
  const x = new THREE.Vector3().subVectors(rightPoint, left).normalize();
  const ySeed = new THREE.Vector3().subVectors(upPoint, origin).normalize();
  const z = new THREE.Vector3().crossVectors(x, ySeed).normalize();
  const y = new THREE.Vector3().crossVectors(z, x).normalize();
  return new THREE.Matrix4().makeBasis(x, y, z);
}

function faceVertexIndices(geometry, intersection) {
  if (intersection.face && Number.isInteger(intersection.face.a)) {
    return [intersection.face.a, intersection.face.b, intersection.face.c].filter(Number.isInteger);
  }
  if (!Number.isInteger(intersection.faceIndex)) return [];
  const triangleOffset = intersection.faceIndex * 3;
  const indexArray = geometry?.index?.array;
  if (indexArray) {
    return [indexArray[triangleOffset], indexArray[triangleOffset + 1], indexArray[triangleOffset + 2]]
      .filter(Number.isInteger);
  }
  return [triangleOffset, triangleOffset + 1, triangleOffset + 2];
}

function smoothstep(edge0, edge1, value) {
  const t = clamp((value - edge0) / Math.max(EPSILON, edge1 - edge0), 0, 1);
  return t * t * (3 - 2 * t);
}

function yieldToBrowser() {
  if (typeof requestAnimationFrame === 'function') {
    return new Promise((resolve) => requestAnimationFrame(() => resolve()));
  }
  return Promise.resolve();
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export const __surfaceTestUtils = Object.freeze({
  deformSurfaceDqs,
  writeFourStrongestInfluences,
  selectWeightCandidates,
  smoothSkinWeights,
  isRestPose,
  rotatePointByQuaternion,
  translationTimesQuaternion,
  dualQuaternionTranslation,
});
