@echo off
setlocal
cd /d "%~dp0"
title Humanoid Rig Lab V8.4

echo.
echo ============================================
echo   Humanoid Rig Lab V8.4 local launcher
echo ============================================
echo.
echo The editor will start immediately.
echo 3D loading order: local Three.js, then online fallback.
echo Keep this window open while using the editor.
echo.

where node >nul 2>nul
if errorlevel 1 goto powershell_fallback

start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:4173/?build=v8.3-anatomical-fit"
node server.mjs
if errorlevel 1 pause
exit /b

:powershell_fallback
echo Node.js was not found.
echo Starting the built-in PowerShell server.
echo The interactive 2D editor works immediately. Online 3D fallback may also work.
start "" cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:4173/?build=v8.3-anatomical-fit"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server-windows.ps1"
if errorlevel 1 (
  echo.
  echo The local server could not start.
  echo Install Node.js 18 or newer, then run this file again.
  pause
)
endlocal
