import assert from 'node:assert/strict';
import {
  createStandardHumanoidPreset,
  normalizeSkeletonDefinition,
} from '../src/skeleton-presets.js';
import {
  applyBodyProfileToDefinition,
  bodyProfileKey,
  measureBodyProfile,
  normalizeBodyProfile,
  REFERENCE_BODY_PROFILE,
} from '../src/body-profile.js';
import { calculateRigHeight, getBoneLength } from '../src/skeleton-model.js';

function assertMetric(actual, expected, label, tolerance = 1e-6) {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual} != ${expected}`);
}

const base = normalizeSkeletonDefinition(createStandardHumanoidPreset('A'));
const baseBind = JSON.stringify(base.joints.map((joint) => [joint.id, joint.parentId, joint.localPosition]));

const reference = applyBodyProfileToDefinition(base, REFERENCE_BODY_PROFILE, { preservePose: false });
const referenceMetrics = measureBodyProfile(reference);
for (const [key, value] of Object.entries(REFERENCE_BODY_PROFILE)) {
  if (typeof value === 'number') assertMetric(referenceMetrics[key], value, `reference ${key}`);
}
assertMetric(calculateRigHeight(reference), REFERENCE_BODY_PROFILE.height, 'reference rig height');
assert.equal(reference.schemaVersion, 6);
assert.equal(reference.profilePreview.requiresSkinRebind, false);
assert.equal(reference.joints.find((joint) => joint.id === 'leftShoulder').visualJoint, false);
assert.equal(reference.joints.find((joint) => joint.id === 'rightShoulder').visualJoint, false);
assert.equal(reference.joints.find((joint) => joint.id === 'leftUpperArm').visualJoint, true);
assert.equal(reference.joints.find((joint) => joint.id === 'rightUpperArm').visualJoint, true);
assert.equal(JSON.stringify(base.joints.map((joint) => [joint.id, joint.parentId, joint.localPosition])), baseBind, 'Profile application mutated the source definition.');

const customProfile = normalizeBodyProfile({
  preset: 'test-custom',
  height: 1.93,
  shoulderWidth: 0.455,
  hipWidth: 0.218,
  upperArmLength: 0.306,
  forearmLength: 0.264,
  handControlLength: 0.077,
  thighLength: 0.472,
  lowerLegLength: 0.438,
});
const custom = applyBodyProfileToDefinition(reference, customProfile, { preservePose: false });
const metrics = measureBodyProfile(custom);
for (const [key, value] of Object.entries(customProfile)) {
  if (typeof value === 'number' && key !== 'draftRevision') assertMetric(metrics[key], value, `custom ${key}`);
}
assertMetric(getBoneLength(custom, 'leftLowerArm'), customProfile.upperArmLength, 'left upper arm');
assertMetric(getBoneLength(custom, 'rightLowerArm'), customProfile.upperArmLength, 'right upper arm');
assertMetric(getBoneLength(custom, 'leftHand'), customProfile.forearmLength, 'left forearm');
assertMetric(getBoneLength(custom, 'rightHand'), customProfile.forearmLength, 'right forearm');
assertMetric(getBoneLength(custom, 'leftLowerLeg'), customProfile.thighLength, 'left thigh');
assertMetric(getBoneLength(custom, 'rightLowerLeg'), customProfile.thighLength, 'right thigh');
assertMetric(getBoneLength(custom, 'leftFoot'), customProfile.lowerLegLength, 'left shank');
assertMetric(getBoneLength(custom, 'rightFoot'), customProfile.lowerLegLength, 'right shank');
assert.equal(custom.profilePreview.requiresSkinRebind, true);
assert.notEqual(bodyProfileKey(customProfile), bodyProfileKey(REFERENCE_BODY_PROFILE));

const clamped = normalizeBodyProfile({ height: 99, shoulderWidth: 0, lowerLegLength: -1 });
assert.equal(clamped.height, 2.15);
assert.equal(clamped.shoulderWidth, 0.28);
assert.equal(clamped.lowerLegLength, 0.30);

console.log('V8.4 live 3D body-profile rebuild, exact requested dimensions, hidden clavicle controls, and rebind boundary checks passed.');
