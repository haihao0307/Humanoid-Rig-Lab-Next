import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { parseGlbMesh } from '../src/glb-geometry.js';

const assetUrl = new URL('../assets/smpl/smpl-male-surface.glb', import.meta.url);
const bytes = await readFile(assetUrl);
assert.ok(bytes.byteLength > 1_000_000 && bytes.byteLength < 2_000_000, `Unexpected GLB size: ${bytes.byteLength}`);

const arrayBuffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
const mesh = parseGlbMesh(arrayBuffer);
assert.equal(mesh.mode, 4);
assert.equal(mesh.vertexCount, 27_578);
assert.equal(mesh.triangleCount, 55_152);
assert.equal(mesh.attributes.position.itemSize, 3);
assert.equal(mesh.attributes.position.count, 27_578);
assert.equal(mesh.attributes.normal.itemSize, 3);
assert.equal(mesh.attributes.normal.count, 27_578);
assert.equal(mesh.attributes.color.itemSize, 4);
assert.equal(mesh.attributes.color.count, 27_578);
assert.equal(mesh.attributes.color.normalized, true);
assert.equal(mesh.index.itemSize, 1);
assert.equal(mesh.index.count, 165_456);
assert.ok(mesh.index.array instanceof Uint32Array);
assert.equal(mesh.metadata.asset.version, '2.0');
assert.match(mesh.metadata.asset.generator, /trimesh/);

const expectedMin = [-0.4785889983177185, -0.006508999969810247, -0.12898600101470947];
const expectedMax = [0.4809800088405609, 1.7891629934310913, 0.2125370055437088];
for (let axis = 0; axis < 3; axis += 1) {
  assert.ok(Math.abs(mesh.attributes.position.min[axis] - expectedMin[axis]) < 1e-8);
  assert.ok(Math.abs(mesh.attributes.position.max[axis] - expectedMax[axis]) < 1e-8);
}

for (const attribute of Object.values(mesh.attributes)) {
  for (let index = 0; index < attribute.array.length; index += Math.max(1, Math.floor(attribute.array.length / 997))) {
    assert.ok(Number.isFinite(attribute.array[index]), 'GLB contains a non-finite attribute value.');
  }
}

const firstColor = Array.from(mesh.attributes.color.array.slice(0, 4));
const lastColor = Array.from(mesh.attributes.color.array.slice(-4));
assert.deepEqual(firstColor, [210, 166, 145, 255]);
assert.deepEqual(lastColor, [210, 166, 145, 255]);

const digest = createHash('sha256').update(bytes).digest('hex');
assert.equal(digest, '68ae60197947ae4581bfd7066b34117d4a3cf7f488b9f676d0ea7fba98a25f03');

console.log('V8.4 local GLB surface parser, topology, bounds, and checksum validation passed.');
