import assert from 'node:assert/strict';
import {
  MIRROR_PAIRS,
  createStandardHumanoidPreset,
  normalizeSkeletonDefinition,
} from '../src/skeleton-presets.js';
import {
  calculateRigHeight,
  computePoseWorldPositions,
  computeRestWorldPositions,
  getBoneLength,
  vectorDistance,
} from '../src/skeleton-model.js';

const EPSILON = 1e-8;
const expectedHeight = 1.795672;
const definitions = new Map();

function close(actual, expected, tolerance = EPSILON, label = 'value') {
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: expected ${expected}, received ${actual}`);
}

for (const pose of ['A', 'T']) {
  const definition = normalizeSkeletonDefinition(createStandardHumanoidPreset(pose));
  definitions.set(pose, definition);

  assert.equal(definition.schemaVersion, 6);
  assert.equal(definition.pose, pose);
  assert.equal(definition.unit, 'meter');
  assert.equal(definition.dimensionsLocked, true);
  assert.equal(definition.bindPose, 'A');
  assert.equal(definition.standard.family, 'SMPL');
  assert.equal(definition.standard.jointLayout, 'SMPL 24');
  assert.equal(definition.standard.license, 'CC BY 4.0');
  assert.equal(definition.surface.asset, 'assets/smpl/smpl-male-surface.glb');
  assert.match(definition.surface.weighting, /region-isolated.*dual-quaternion.*bind-pose/i);
  assert.equal(definition.anthropometry.profile, 'smpl-male-surface-fit-1796-v3');
  assert.equal(definition.physics.solverIterations, 64);
  assert.equal(definition.physics.poseStiffness, 0.20);
  assert.equal(definition.physics.anatomyEnabled, true);
  assert.equal(definition.biomechanics.enabled, true);
  assert.equal(definition.biomechanics.hardLimits, true);
  assert.equal(definition.joints.length, 28);
  assert.equal(definition.joints.filter((joint) => !joint.isControl).length, 27);

  const byId = new Map(definition.joints.map((joint) => [joint.id, joint]));
  assert.equal(byId.size, definition.joints.length, 'Joint IDs must be unique.');
  assert.equal(byId.get('root')?.parentId, null);
  assert.equal(byId.get('root')?.isControl, true);
  assert.equal(byId.get('root')?.visualJoint, false);
  assert.equal(byId.get('root')?.physicalBone, false);
  assert.equal(byId.get('hips')?.parentId, 'root');
  assert.equal(byId.get('hips')?.visualBone, false);
  assert.equal(byId.get('hips')?.physicalBone, false);
  assert.equal(byId.get('leftUpperLeg')?.visualBone, false);
  assert.equal(byId.get('rightUpperLeg')?.visualBone, false);
  assert.equal(byId.get('leftUpperLeg')?.physicalBone, true);
  assert.equal(byId.get('rightUpperLeg')?.physicalBone, true);
  close(calculateRigHeight(definition), expectedHeight, EPSILON, 'rig height');

  const standardJoints = definition.joints.filter((joint) => joint.standard?.family === 'SMPL');
  assert.equal(standardJoints.length, 24, 'SMPL mapping must contain exactly 24 joints.');
  const smplIndices = standardJoints.map((joint) => joint.standard.index).sort((a, b) => a - b);
  assert.deepEqual(smplIndices, Array.from({ length: 24 }, (_, index) => index));
  assert.equal(definition.joints.filter((joint) => joint.standard?.helper).length, 4);

  const rest = computeRestWorldPositions(definition);
  const currentPose = computePoseWorldPositions(definition);
  for (const joint of definition.joints) {
    assert.equal(joint.localPosition.length, 3);
    assert.equal(joint.poseWorldPosition.length, 3);
    if (joint.parentId && joint.physicalBone !== false) {
      const expected = getBoneLength(definition, joint.id);
      const actual = vectorDistance(currentPose.get(joint.parentId), currentPose.get(joint.id));
      close(actual, expected, EPSILON, `${pose} ${joint.id} fixed length`);
    }
    if (!joint.parentId) assert.deepEqual(rest.get(joint.id), currentPose.get(joint.id));
  }

  for (const [sourceId, targetId] of Object.entries(MIRROR_PAIRS)) {
    const source = byId.get(sourceId);
    const target = byId.get(targetId);
    assert.ok(source, `Missing source mirror joint ${sourceId}.`);
    assert.ok(target, `Missing target mirror joint ${targetId}.`);
    close(source.localPosition[0], -target.localPosition[0], EPSILON, `${sourceId}/${targetId} mirrored X`);
    close(source.localPosition[1], target.localPosition[1], EPSILON, `${sourceId}/${targetId} mirrored Y`);
    close(source.localPosition[2], target.localPosition[2], EPSILON, `${sourceId}/${targetId} mirrored Z`);
  }
}

const aDefinition = definitions.get('A');
const tDefinition = definitions.get('T');
const tPose = computePoseWorldPositions(tDefinition);
close(vectorDistance(tPose.get('leftHandEnd'), tPose.get('rightHandEnd')), 1.598789537441861, EPSILON, 'T-pose hand-control span');
close(vectorDistance(tPose.get('leftUpperLeg'), tPose.get('rightUpperLeg')), 0.2, EPSILON, 'hip joint width');

close(getBoneLength(tDefinition, 'leftUpperArm'), 0.12864680330268607, EPSILON, 'clavicle to shoulder');
close(getBoneLength(tDefinition, 'leftLowerArm'), 0.27721832551258224, EPSILON, 'upper arm');
close(getBoneLength(tDefinition, 'leftHand'), 0.2414021540914662, EPSILON, 'forearm');
close(getBoneLength(tDefinition, 'leftHandEnd'), 0.070774289116882, EPSILON, 'wrist to hand node');
close(getBoneLength(tDefinition, 'leftLowerLeg'), 0.4253480927428734, EPSILON, 'thigh');
close(getBoneLength(tDefinition, 'leftFoot'), 0.4031327324839798, EPSILON, 'shank');
close(getBoneLength(tDefinition, 'leftToes'), 0.13915818337417316, EPSILON, 'ankle to forefoot node');

const upperArmToForearm = getBoneLength(tDefinition, 'leftLowerArm') / getBoneLength(tDefinition, 'leftHand');
close(upperArmToForearm, 1.1483672403666518, 1e-6, 'upper arm to forearm ratio');
assert.ok(getBoneLength(tDefinition, 'leftHandEnd') < 0.08, 'The hand control remains too far from the wrist.');
assert.ok(getBoneLength(tDefinition, 'leftFoot') < getBoneLength(tDefinition, 'leftLowerLeg'), 'The shank must remain shorter than the thigh in this fitted profile.');

const restA = computeRestWorldPositions(aDefinition);
const expectedFit = {
  hips: [0, 0.925, 0.016],
  leftUpperArm: [-0.210, 1.340, -0.020],
  leftLowerArm: [-0.350, 1.105, 0.025],
  leftHand: [-0.435, 0.900, 0.120],
  leftLowerLeg: [-0.110, 0.500, 0.002],
  leftFoot: [-0.160, 0.100, -0.002],
  leftToes: [-0.176, 0.035, 0.120],
};
for (const [id, expected] of Object.entries(expectedFit)) {
  const point = restA.get(id);
  close(point.x, expected[0], EPSILON, `${id} fitted X`);
  close(point.y, expected[1], EPSILON, `${id} fitted Y`);
  close(point.z, expected[2], EPSILON, `${id} fitted Z`);
}

for (const joint of aDefinition.joints) {
  const counterpart = tDefinition.joints.find((item) => item.id === joint.id);
  assert.ok(counterpart);
  assert.deepEqual(joint.localPosition, counterpart.localPosition, `${joint.id} bind data differs by pose.`);
  close(getBoneLength(aDefinition, joint.id), getBoneLength(tDefinition, joint.id), 1e-12, `${joint.id} pose-independent length`);
}

console.log('V8.4 SMPL 24 mapping, fitted anatomical joints, and fixed segment data validation passed.');
