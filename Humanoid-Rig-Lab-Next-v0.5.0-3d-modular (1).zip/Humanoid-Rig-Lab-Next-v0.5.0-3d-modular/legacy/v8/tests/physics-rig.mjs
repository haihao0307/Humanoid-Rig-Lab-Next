import assert from 'node:assert/strict';
import {
  createStandardHumanoidPreset,
  normalizeSkeletonDefinition,
} from '../src/skeleton-presets.js';
import {
  applyPosePayload,
  buildExportPayload,
  buildPosePayload,
  calculateRigHeight,
  computePoseWorldPositions,
  getBoneLength,
  vectorDistance,
} from '../src/skeleton-model.js';
import { PhysicsRig } from '../src/physics-rig.js';

const LENGTH_TOLERANCE = 1e-5;
const PELVIS_TOLERANCE = 1e-4;
const ANGLE_TOLERANCE = 0.05;

function createRig(options = {}) {
  const definition = normalizeSkeletonDefinition(createStandardHumanoidPreset('A'));
  const rig = new PhysicsRig(definition, {
    solverIterations: 64,
    exactMaxPasses: 960,
    exactTolerance: 1e-8,
    groundEnabled: true,
    gravityEnabled: false,
    poseStiffness: 0.20,
    anatomyEnabled: true,
    ...options,
  });
  return { definition, rig };
}

function bindSnapshot(definition) {
  return JSON.stringify(definition.joints.map((joint) => ({
    id: joint.id,
    parentId: joint.parentId,
    localPosition: [...joint.localPosition],
    jointRadius: joint.jointRadius,
    boneRadius: joint.boneRadius,
    physicalBone: joint.physicalBone,
    visualBone: joint.visualBone,
    visualJoint: joint.visualJoint,
    jointType: joint.jointType,
    limitLabel: joint.limitLabel,
  })));
}

function pointMap(rig, definition) {
  return new Map(definition.joints.map((joint) => [joint.id, rig.getPoint(joint.id)]));
}

function pointMovement(before, after) {
  return vectorDistance(before, after);
}

function assertSolved(rig, message) {
  const lengthError = rig.getMaxBoneError();
  const jointViolation = rig.getMaxJointLimitViolation();
  const pelvisError = rig.getRigidPelvisError();
  assert.ok(lengthError < LENGTH_TOLERANCE, `${message}: maximum bone error ${lengthError} m.`);
  assert.ok(jointViolation < ANGLE_TOLERANCE, `${message}: joint violation ${jointViolation} degrees.`);
  assert.ok(pelvisError < PELVIS_TOLERANCE, `${message}: rigid pelvis error ${pelvisError} m.`);
}

function assertBindUnchanged(definition, snapshot, message) {
  assert.equal(bindSnapshot(definition), snapshot, message);
}

// Joint dragging propagates through the body while dimensions, pelvis width,
// and all supported anatomical limits remain hard constraints.
{
  const { definition, rig } = createRig();
  const immutableBind = bindSnapshot(definition);
  const before = pointMap(rig, definition);
  const pelvisWidthBefore = vectorDistance(rig.getPoint('leftUpperLeg'), rig.getPoint('rightUpperLeg'));
  const hand = rig.getPoint('leftHand');
  const target = { x: hand.x - 0.4, y: hand.y + 0.25, z: hand.z + 0.15 };

  assert.equal(rig.beginDrag({ jointId: 'leftHand', kind: 'joint', anchorWorld: hand }), true);
  assert.equal(rig.updateDragTarget(target), true);
  assertSolved(rig, 'Joint drag during interaction');

  const movedAnatomical = definition.joints.filter((joint) => (
    !joint.isControl && pointMovement(before.get(joint.id), rig.getPoint(joint.id)) > 1e-5
  ));
  assert.ok(movedAnatomical.length >= 20, `Only ${movedAnatomical.length} anatomical joints reacted.`);
  assert.ok(pointMovement(before.get('leftHand'), rig.getPoint('leftHand')) > 0.25);
  assert.ok(pointMovement(before.get('upperChest'), rig.getPoint('upperChest')) > 0.05);
  assert.ok(pointMovement(before.get('hips'), rig.getPoint('hips')) > 0.001);
  assert.ok(pointMovement(before.get('rightHand'), rig.getPoint('rightHand')) > 0.015);

  assert.equal(rig.endDrag({ keepMomentum: false }), true);
  assertSolved(rig, 'Joint drag after release');
  assertBindUnchanged(definition, immutableBind, 'Joint dragging changed immutable model dimensions.');
  const pelvisWidthAfter = vectorDistance(rig.getPoint('leftUpperLeg'), rig.getPoint('rightUpperLeg'));
  assert.ok(Math.abs(pelvisWidthAfter - pelvisWidthBefore) < PELVIS_TOLERANCE);

  const root = rig.getPoint('root');
  const hips = rig.getPoint('hips');
  const rootDefinition = definition.joints.find((joint) => joint.id === 'root');
  const controlOffset = rootDefinition.controlOffset;
  assert.ok(Math.abs(root.x - (hips.x + controlOffset[0])) < 1e-10);
  assert.ok(Math.abs(root.y - (hips.y + controlOffset[1])) < 1e-10);
  assert.ok(Math.abs(root.z - (hips.z + controlOffset[2])) < 1e-10);
}

// A rendered bone acts as a two-endpoint handle and still obeys joint limits.
{
  const { definition, rig } = createRig();
  const immutableBind = bindSnapshot(definition);
  const before = pointMap(rig, definition);
  const parent = rig.getPoint('leftUpperArm');
  const child = rig.getPoint('leftLowerArm');
  const midpoint = {
    x: (parent.x + child.x) / 2,
    y: (parent.y + child.y) / 2,
    z: (parent.z + child.z) / 2,
  };

  assert.equal(rig.beginDrag({ jointId: 'leftLowerArm', kind: 'bone', anchorWorld: midpoint }), true);
  assert.equal(rig.updateDragTarget({
    x: midpoint.x + 0.35,
    y: midpoint.y + 0.25,
    z: midpoint.z + 0.20,
  }), true);
  assertSolved(rig, 'Bone drag during interaction');
  assert.ok(pointMovement(before.get('leftUpperArm'), rig.getPoint('leftUpperArm')) > 0.15);
  assert.ok(pointMovement(before.get('leftLowerArm'), rig.getPoint('leftLowerArm')) > 0.15);
  assert.ok(pointMovement(before.get('hips'), rig.getPoint('hips')) > 0.001);

  rig.endDrag({ keepMomentum: false });
  assertSolved(rig, 'Bone drag after release');
  assertBindUnchanged(definition, immutableBind, 'Bone dragging changed immutable model dimensions.');
}

// Impossible elbow, knee, wrist and ankle requests are projected back into the
// configured adult range of motion.
{
  const { rig } = createRig({ solverIterations: 96 });
  const hand = rig.getPoint('leftHandEnd');
  rig.moveJointTo('leftHandEnd', { x: hand.x + 1.5, y: hand.y + 1.2, z: hand.z - 1.5 });
  assertSolved(rig, 'Extreme arm target');
  assert.equal(rig.getJointLimitInfo('leftLowerArm').withinLimits, true);
  assert.equal(rig.getJointLimitInfo('leftHand').withinLimits, true);

  const toes = rig.getPoint('leftToesEnd');
  rig.moveJointTo('leftToesEnd', { x: toes.x + 1.2, y: toes.y + 1.5, z: toes.z - 1.2 });
  assertSolved(rig, 'Extreme leg target');
  assert.equal(rig.getJointLimitInfo('leftLowerLeg').withinLimits, true);
  assert.equal(rig.getJointLimitInfo('leftFoot').withinLimits, true);
  assert.equal(rig.getJointLimitInfo('leftToes').withinLimits, true);
}

// Unreachable targets yield while pinned supports, segment lengths and joint
// envelopes remain intact.
{
  const { definition, rig } = createRig({ solverIterations: 96 });
  const immutableBind = bindSnapshot(definition);
  rig.setPinned('leftFoot', true);
  rig.setPinned('rightFoot', true);
  const leftFoot = rig.getPoint('leftFoot');
  const rightFoot = rig.getPoint('rightFoot');
  const hand = rig.getPoint('leftHand');

  rig.beginDrag({ jointId: 'leftHand', kind: 'joint', anchorWorld: hand });
  rig.updateDragTarget({ x: -100, y: 100, z: 50 });
  assert.ok(rig.getMaxBoneError() < 2e-5, 'Extreme drag produced visible bone stretching.');
  assert.ok(rig.getMaxJointLimitViolation() < 4, 'Extreme drag escaped the anatomical envelope.');
  assert.ok(rig.getRigidPelvisError() < 1e-4, 'Extreme drag opened the rigid pelvis.');
  assert.ok(rig.getDragTargetError() > 10, 'An unreachable target incorrectly forced the rig to the mouse.');
  rig.endDrag({ keepMomentum: false });
  for (let frame = 0; frame < 60; frame += 1) rig.step(1 / 60);

  assertSolved(rig, 'Unreachable target after settling');
  assert.ok(vectorDistance(leftFoot, rig.getPoint('leftFoot')) < 1e-10, 'Left pinned foot moved.');
  assert.ok(vectorDistance(rightFoot, rig.getPoint('rightFoot')) < 1e-10, 'Right pinned foot moved.');
  assertBindUnchanged(definition, immutableBind, 'Unreachable target changed immutable model dimensions.');
}

// Conflicting pose JSON is reconciled against the revised fixed rig.
{
  const { definition, rig } = createRig();
  const immutableBind = bindSnapshot(definition);
  const payload = buildPosePayload(definition);
  for (const item of payload.joints) {
    if (item.id === 'leftLowerArm') {
      item.poseWorldPosition = { x: 0, y: 0, z: 0 };
      item.pinned = true;
    }
    if (item.id === 'leftHand') {
      item.poseWorldPosition = { x: 5, y: 5, z: 5 };
      item.pinned = true;
    }
  }
  assert.equal(applyPosePayload(definition, payload), 28);
  rig.resetFromDefinitionPose({ project: true });
  assertSolved(rig, 'Reconciled imported pose');
  assert.equal(definition.joints.find((joint) => joint.id === 'leftLowerArm').pinned, true);
  assert.equal(definition.joints.find((joint) => joint.id === 'leftHand').pinned, true);
  assertBindUnchanged(definition, immutableBind, 'Pose JSON changed immutable model dimensions.');
}

// Export records hidden and physical links separately.
{
  const { definition, rig } = createRig();
  const hand = rig.getPoint('rightHand');
  rig.moveJointTo('rightHand', { x: hand.x + 0.25, y: hand.y + 0.15, z: hand.z + 0.1 });
  const exported = buildExportPayload(definition);
  assert.equal(exported.dimensionsLocked, true);
  assert.equal(exported.schemaVersion, 6);
  assert.ok(exported.joints.every((joint) => 'localPosition' in joint));
  assert.ok(exported.joints.every((joint) => 'poseWorldPosition' in joint));
  assert.equal(exported.joints.find((joint) => joint.id === 'hips').lengthLocked, false);
  assert.equal(exported.joints.find((joint) => joint.id === 'hips').visualBone, false);
  assert.equal(exported.joints.find((joint) => joint.id === 'leftUpperLeg').lengthLocked, true);
  assert.equal(exported.joints.find((joint) => joint.id === 'leftUpperLeg').visualBone, false);
  assert.ok(Math.abs(calculateRigHeight(definition) - 1.795672) < 1e-9);

  const pose = computePoseWorldPositions(definition);
  for (const joint of definition.joints) {
    if (!joint.parentId || joint.physicalBone === false) continue;
    const actualLength = vectorDistance(pose.get(joint.parentId), pose.get(joint.id));
    assert.ok(Math.abs(actualLength - getBoneLength(definition, joint.id)) < LENGTH_TOLERANCE);
  }
}

console.log('V8.4 fixed dimensions, whole-body propagation, and anatomical ROM checks passed.');
