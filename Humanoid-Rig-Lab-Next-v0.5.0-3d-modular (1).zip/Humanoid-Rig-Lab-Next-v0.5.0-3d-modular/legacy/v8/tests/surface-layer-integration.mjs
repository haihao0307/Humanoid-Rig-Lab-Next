import { readFile } from 'node:fs/promises';
import { createSmplSkinLayer } from '../src/smpl-skin.js';
import { createStandardHumanoidPreset, normalizeSkeletonDefinition } from '../src/skeleton-presets.js';

const assetPath = new URL('../assets/smpl/smpl-male-surface.glb', import.meta.url);
globalThis.fetch = async () => {
  const buffer = await readFile(assetPath);
  return {
    ok: true,
    status: 200,
    arrayBuffer: async () => buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength),
  };
};

class V3 {
  constructor(x = 0, y = 0, z = 0) { this.x = x; this.y = y; this.z = z; }
  set(x, y, z) { this.x = x; this.y = y; this.z = z; return this; }
  copy(v) { this.x = v.x; this.y = v.y; this.z = v.z; return this; }
  clone() { return new V3(this.x, this.y, this.z); }
  sub(v) { this.x -= v.x; this.y -= v.y; this.z -= v.z; return this; }
  add(v) { this.x += v.x; this.y += v.y; this.z += v.z; return this; }
  multiplyScalar(value) { this.x *= value; this.y *= value; this.z *= value; return this; }
  subVectors(a, b) { this.x = a.x - b.x; this.y = a.y - b.y; this.z = a.z - b.z; return this; }
  crossVectors(a, b) { this.x = a.y * b.z - a.z * b.y; this.y = a.z * b.x - a.x * b.z; this.z = a.x * b.y - a.y * b.x; return this; }
  lengthSq() { return this.x * this.x + this.y * this.y + this.z * this.z; }
  length() { return Math.sqrt(this.lengthSq()); }
  normalize() { const length = this.length() || 1; return this.multiplyScalar(1 / length); }
  fromArray(values) { this.x = values[0]; this.y = values[1]; this.z = values[2]; return this; }
  lerp(target, alpha) { this.x += (target.x - this.x) * alpha; this.y += (target.y - this.y) * alpha; this.z += (target.z - this.z) * alpha; return this; }
}

class Q {
  constructor(x = 0, y = 0, z = 0, w = 1) { this.x = x; this.y = y; this.z = z; this.w = w; }
  identity() { this.x = 0; this.y = 0; this.z = 0; this.w = 1; return this; }
  copy(q) { this.x = q.x; this.y = q.y; this.z = q.z; this.w = q.w; return this; }
  setFromUnitVectors(vFrom, vTo) {
    let r = vFrom.x * vTo.x + vFrom.y * vTo.y + vFrom.z * vTo.z + 1;
    if (r < 1e-8) {
      r = 0;
      if (Math.abs(vFrom.x) > Math.abs(vFrom.z)) {
        this.x = -vFrom.y; this.y = vFrom.x; this.z = 0; this.w = r;
      } else {
        this.x = 0; this.y = -vFrom.z; this.z = vFrom.y; this.w = r;
      }
    } else {
      this.x = vFrom.y * vTo.z - vFrom.z * vTo.y;
      this.y = vFrom.z * vTo.x - vFrom.x * vTo.z;
      this.z = vFrom.x * vTo.y - vFrom.y * vTo.x;
      this.w = r;
    }
    return this.normalize();
  }
  setFromRotationMatrix(matrix) {
    const te = matrix.elements;
    const m11 = te[0], m12 = te[4], m13 = te[8];
    const m21 = te[1], m22 = te[5], m23 = te[9];
    const m31 = te[2], m32 = te[6], m33 = te[10];
    const trace = m11 + m22 + m33;
    if (trace > 0) {
      const s = 0.5 / Math.sqrt(trace + 1);
      this.w = 0.25 / s;
      this.x = (m32 - m23) * s;
      this.y = (m13 - m31) * s;
      this.z = (m21 - m12) * s;
    } else if (m11 > m22 && m11 > m33) {
      const s = 2 * Math.sqrt(1 + m11 - m22 - m33);
      this.w = (m32 - m23) / s; this.x = 0.25 * s; this.y = (m12 + m21) / s; this.z = (m13 + m31) / s;
    } else if (m22 > m33) {
      const s = 2 * Math.sqrt(1 + m22 - m11 - m33);
      this.w = (m13 - m31) / s; this.x = (m12 + m21) / s; this.y = 0.25 * s; this.z = (m23 + m32) / s;
    } else {
      const s = 2 * Math.sqrt(1 + m33 - m11 - m22);
      this.w = (m21 - m12) / s; this.x = (m13 + m31) / s; this.y = (m23 + m32) / s; this.z = 0.25 * s;
    }
    return this;
  }
  multiply(q) {
    const qax = this.x, qay = this.y, qaz = this.z, qaw = this.w;
    const qbx = q.x, qby = q.y, qbz = q.z, qbw = q.w;
    this.x = qax * qbw + qaw * qbx + qay * qbz - qaz * qby;
    this.y = qay * qbw + qaw * qby + qaz * qbx - qax * qbz;
    this.z = qaz * qbw + qaw * qbz + qax * qby - qay * qbx;
    this.w = qaw * qbw - qax * qbx - qay * qby - qaz * qbz;
    return this;
  }
  invert() { this.x *= -1; this.y *= -1; this.z *= -1; return this; }
  normalize() { const length = Math.sqrt(this.x ** 2 + this.y ** 2 + this.z ** 2 + this.w ** 2) || 1; this.x /= length; this.y /= length; this.z /= length; this.w /= length; return this; }
}

class M4 {
  constructor() { this.elements = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]; }
  makeBasis(x, y, z) { this.elements = [x.x, x.y, x.z, 0, y.x, y.y, y.z, 0, z.x, z.y, z.z, 0, 0, 0, 0, 1]; return this; }
}

class Obj {
  constructor() {
    this.children = [];
    this.visible = true;
    this.userData = {};
    this.position = new V3();
    this.quaternion = new Q();
    this.scale = new V3(1, 1, 1);
  }
  add(object) { this.children.push(object); object.parent = this; }
}
class Group extends Obj {}
class Scene extends Group { remove(object) { this.children = this.children.filter((item) => item !== object); if (object?.parent === this) object.parent = null; } }
class Material { constructor(parameters = {}) { Object.assign(this, parameters); this.type = 'MeshStandardMaterial'; this.needsUpdate = false; } dispose() {} }
class BasicGeometry { dispose() {} }
class SphereGeometry extends BasicGeometry {}
class CylinderGeometry extends BasicGeometry {}
class Mesh extends Obj { constructor(geometry, material) { super(); this.geometry = geometry; this.material = material; this.frustumCulled = true; this.renderOrder = 0; } }
class Attr {
  constructor(array, itemSize, normalized = false) { this.array = array; this.itemSize = itemSize; this.normalized = normalized; this.count = array.length / itemSize; this.needsUpdate = false; }
  setUsage(value) { this.usage = value; return this; }
}
class Geo {
  constructor() { this.attributes = {}; this.index = null; }
  setAttribute(name, attribute) { this.attributes[name] = attribute; return this; }
  setIndex(attribute) { this.index = attribute; return this; }
  computeBoundingBox() {}
  computeBoundingSphere() {}
  dispose() {}
}

const THREE = {
  Vector3: V3,
  Quaternion: Q,
  Matrix4: M4,
  Group,
  MeshStandardMaterial: Material,
  Mesh,
  SphereGeometry,
  CylinderGeometry,
  BufferGeometry: Geo,
  Float32BufferAttribute: Attr,
  BufferAttribute: Attr,
  DoubleSide: 2,
  DynamicDrawUsage: 35048,
};

const states = [];
const scene = new Scene();
const definition = normalizeSkeletonDefinition(createStandardHumanoidPreset('A'));
const start = performance.now();
const layer = await createSmplSkinLayer(THREE, scene, definition, {
  onSurfaceState: (state) => states.push(state),
});

const immediate = layer.getDiagnostics();
if (immediate.type !== 'single-smpl-human-surface') throw new Error(`Unexpected layer type: ${immediate.type}`);
if (immediate.proceduralSurfacePresent !== false) throw new Error('A procedural human surface was created.');
if (immediate.renderableSurfaceCount > 1) throw new Error('More than one human surface exists during loading.');
if (immediate.requestedSource !== 'detail') throw new Error('Surface source is not locked to detail.');

const pending = layer.detailPromise;
if (!pending) throw new Error('Detailed surface loading did not start.');
await pending;
const diagnostics = layer.getDiagnostics();
if (diagnostics.type !== 'single-smpl-human-surface') throw new Error('Detailed surface layer type changed unexpectedly.');
if (!diagnostics.visible || !diagnostics.meshVisible || !diagnostics.weightsReady) throw new Error('Detailed surface did not become visible and ready.');
if (!diagnostics.attachedToScene) throw new Error('The single surface is not attached to the render scene.');
if (!diagnostics.singleVisibleSurface || diagnostics.renderableSurfaceCount !== 1) throw new Error('The render scene contains an invalid surface count.');
if (diagnostics.proceduralSurfacePresent) throw new Error('A procedural selection shell remains present.');
if (diagnostics.pickSource !== 'detailed-smpl-mesh') throw new Error('Picking is not performed on the detailed mesh.');
if (diagnostics.vertexCount !== 27578 || diagnostics.triangleCount !== 55152) throw new Error('Unexpected detailed surface topology.');
if (!diagnostics.bindPoseProtected) throw new Error('The exact A bind pose did not preserve original vertices.');
if (states[0]?.state !== 'loading') throw new Error('The first surface state must be loading.');
if (states.at(-1)?.state !== 'ready') throw new Error('Surface state did not reach ready.');

const targets = layer.getPickTargets();
if (targets.length !== 1) throw new Error(`Expected one direct mesh pick target, received ${targets.length}.`);
const resolved = layer.resolvePick({
  object: targets[0],
  faceIndex: 0,
  distance: 1,
  point: new V3(),
});
if (!resolved?.jointId || resolved.surfacePart !== 'detailed-smpl-mesh') throw new Error('Detailed mesh pick did not resolve to a joint.');

const materialBefore = targets[0].material;
layer.refresh(definition, { selectedJointId: 'leftHand', hoveredJointId: 'leftLowerArm', hoveredKind: 'joint' });
if (targets[0].material !== materialBefore) throw new Error('Joint selection changed the human surface material.');

layer.setSource('base');
const lockedSource = layer.getDiagnostics();
if (lockedSource.activeSource !== 'detail' || lockedSource.requestedSource !== 'detail') throw new Error('Legacy source selection created another surface.');

layer.setVisible(false);
const hidden = layer.getDiagnostics();
if (hidden.renderableSurfaceCount !== 0 || layer.getPickTargets().length !== 0) throw new Error('Hidden surface mode left rendering or picking active.');
layer.setVisible(true);

const tDefinition = normalizeSkeletonDefinition(createStandardHumanoidPreset('T'));
layer.refresh(tDefinition, null, { force: true });
if (layer.getDiagnostics().bindPoseProtected) throw new Error('T pose incorrectly used bind-pose vertex protection.');

const deformed = targets[0].geometry.attributes.position.array;
const rest = layer.restPositions;
const triangleIndex = targets[0].geometry.index?.array;
let maxDisplacement = 0;
let maxEdgeStretch = 0;
let maxShoulderEdgeStretch = 0;
let nonFiniteCount = 0;
for (let i = 0; i < deformed.length; i += 3) {
  const dx = deformed[i] - rest[i];
  const dy = deformed[i + 1] - rest[i + 1];
  const dz = deformed[i + 2] - rest[i + 2];
  const displacement = Math.hypot(dx, dy, dz);
  if (!Number.isFinite(displacement)) nonFiniteCount += 1;
  maxDisplacement = Math.max(maxDisplacement, displacement);
}
const edgeLength = (array, a, b) => {
  const ao = a * 3;
  const bo = b * 3;
  return Math.hypot(array[ao] - array[bo], array[ao + 1] - array[bo + 1], array[ao + 2] - array[bo + 2]);
};
if (triangleIndex) {
  for (let i = 0; i < triangleIndex.length; i += 3) {
    const ids = [triangleIndex[i], triangleIndex[i + 1], triangleIndex[i + 2]];
    for (const [a, b] of [[ids[0], ids[1]], [ids[1], ids[2]], [ids[2], ids[0]]]) {
      const before = edgeLength(rest, a, b);
      if (before < 1e-5) continue;
      const after = edgeLength(deformed, a, b);
      const ratio = after / before;
      if (ratio > maxEdgeStretch) maxEdgeStretch = ratio;
      const ao = a * 3;
      const bo = b * 3;
      const midX = (rest[ao] + rest[bo]) * 0.5;
      const midY = (rest[ao + 1] + rest[bo + 1]) * 0.5;
      if (midY >= 1.18 && midY <= 1.48 && Math.abs(midX) >= 0.12 && Math.abs(midX) <= 0.36) {
        maxShoulderEdgeStretch = Math.max(maxShoulderEdgeStretch, ratio);
      }
    }
  }
}
if (nonFiniteCount) throw new Error(`T pose generated ${nonFiniteCount} non-finite vertices.`);
if (maxDisplacement >= 0.75) {
  throw new Error(`T pose moved a surface vertex too far: ${maxDisplacement.toFixed(4)} m.`);
}
if (maxEdgeStretch >= 6.2) {
  throw new Error(`T pose triangle-edge stretch exceeded the guarded limit: ${maxEdgeStretch.toFixed(3)}x.`);
}
if (maxShoulderEdgeStretch >= 1.8) {
  throw new Error(`T pose shoulder-edge stretch exceeded the guarded limit: ${maxShoulderEdgeStretch.toFixed(3)}x.`);
}

console.log(
  `T-pose mesh quality passed: max displacement ${maxDisplacement.toFixed(4)} m, `
  + `max edge stretch ${maxEdgeStretch.toFixed(3)}x, `
  + `max shoulder stretch ${maxShoulderEdgeStretch.toFixed(3)}x.`,
);

const elapsed = performance.now() - start;
console.log(`V8.4 single detailed mesh, direct weighted picking, smoothed regional DQS, and bind-pose protection passed in ${elapsed.toFixed(1)} ms.`);
