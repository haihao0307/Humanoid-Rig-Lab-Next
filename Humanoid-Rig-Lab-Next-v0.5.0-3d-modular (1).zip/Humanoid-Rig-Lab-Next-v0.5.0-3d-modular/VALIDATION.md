# Humanoid Rig Lab Next V0.5.0 验证记录

验证日期：2026 年 8 月 19 日

## 验证命令

```text
npm test
```

## 测试结果摘要

```text
PASS Humanoid Rig Lab Next 0.5.0
PASS 44 required files
PASS V0.5 schema, module state, and migration contract
PASS primary 3D proportion stage and explicit 2D fallback separation
PASS live body-profile bridge and exact 3D dimension feedback contract
PASS module-scoped synchronization and rig-rule exchange contract
PASS hidden clavicle controls and visible shoulder-joint semantics
PASS JavaScript syntax checks
PASS SMPL GLB asset 1435300 bytes
PASS GitHub Pages workflow contract
PASS module-scoped patches merge simultaneous four-window edits without overwriting unrelated modules
PASS legacy surface-source fields are forced onto the single detailed surface
PASS schema v1 project migration to schema v5

V8.4 SMPL 24 mapping, fitted anatomical joints, and fixed segment data validation passed.
V8.4 live 3D body-profile rebuild, exact requested dimensions, hidden clavicle controls, and rebind boundary checks passed.
V8.4 fixed dimensions, whole-body propagation, and anatomical ROM checks passed.
V8.4 local GLB surface parser, topology, bounds, and checksum validation passed.
V8.4 dual-quaternion deformation, regional weighting, bind-pose protection, and four-influence normalization checks passed.
T-pose mesh quality passed: max displacement 0.6531 m, max edge stretch 5.632x, max shoulder stretch 1.645x.
V8.4 single detailed mesh, direct weighted picking, smoothed regional DQS, and bind-pose protection passed.
V8.4 single detailed surface, anatomical fit, host bridge, direct body picking, launchers, and integration checks passed.
```

## 1. 三维比例工作台

验证内容：

```text
比例工作台启动时显示 V8.4 Three.js 三维视口
轻量 Canvas 默认隐藏
CSS hidden 状态具有最高优先级
Three.js 故障时可以切换轻量后备层
母平台发送 HRL_PREVIEW_BODY_PROFILE
V8.4 返回 HRL_PROFILE_STATUS
实际三维测量值回传母平台
```

八项可调绑定尺寸均通过精确测量测试：

```text
身高
肩关节中心宽度
髋关节中心宽度
上臂长度
前臂长度
腕到手部控制点
大腿长度
小腿长度
```

## 2. 骨骼显示和数据规则

验证内容：

```text
SMPL 24 映射完整
编辑器节点总数 28
绑定骨骼 ID 稳定
左右镜像规则有效
固定骨长有效
锁骨控制点 visualJoint=false
每侧只有一个可见肩关节
Rig export schemaVersion 6
```

参考体型数据：

```text
身高 1.795672 m
肩关节中心宽度 0.420 m
髋关节中心宽度 0.200 m
上臂 0.277218 m
前臂 0.241402 m
手部控制段 0.070774 m
大腿 0.425348 m
小腿 0.403133 m
```

## 3. 比例与表皮兼容边界

任一绑定尺寸变化都会标记：

```text
requiresRebind = true
```

比例模块生成新的绑定草案后，蒙皮模块需要发布兼容该 rigVersion 的 SkinBinding。当前精细人体属于参考和实验表皮路径。

## 4. 四模块独立状态

验证内容：

```text
proportion moduleRevision
skin moduleRevision
pose moduleRevision
animation moduleRevision
integration moduleRevision
```

接近同时提交比例和蒙皮 Patch 时，各自拥有的数据切片都能保留。过期 Patch 会被拒绝。

模块代码已经拆分为：

```text
src/modules/proportion/
src/modules/skin/
src/modules/pose/
src/modules/animation/
src/modules/integration/
```

## 5. 四对话协作资料

验证以下文件存在：

```text
docs/FOUR_MODULE_COLLABORATION.md
docs/CHAT_WINDOW_START_PROMPTS.md
docs/GITHUB_BRANCH_WORKFLOW.md
control/handoffs/HANDOFF_TEMPLATE.md
.github/PULL_REQUEST_TEMPLATE.md
PREPARE_BRANCHES.cmd
scripts/prepare-module-branches.ps1
```

分支准备脚本包含：

```text
integration
work/proportion
work/skin
work/pose
work/animation
```

## 6. 人体物理和表面算法

V8.4 自动测试覆盖：

```text
固定骨长
刚性骨盆
双脚固定
人体关节活动范围
全身联动
GLB 解析
区域权重隔离
四骨骼影响归一化
三角形邻接平滑
双四元数变形
绑定姿势原始顶点保护
精细网格直接拾取
```

当前完整 GLB 数据：

```text
27,578 个渲染顶点
55,152 个三角形
文件大小 1,435,300 字节
```

## 7. Windows 启动和本地服务器

验证内容：

```text
ASCII start.bat
launcher.ps1
Node.js 18 以上路径
PowerShell 后备服务器
Three.js 0.185.1 安装路径
GLB Content-Type 为 model/gltf-binary
JavaScript MIME 类型
Cross-Origin-Opener-Policy
```

本地 HTTP 冒烟测试通过：

```text
GET /
GET /studio.html?module=proportion
HEAD /legacy/v8/assets/smpl/smpl-male-surface.glb
```

## 8. GitHub 工作流

验证内容：

```text
main、integration 和 work/** 分支触发自动测试
Pull Request 验证
GitHub Pages Actions 工作流
验证报告 Artifact
手动分支准备脚本
Pull Request 模板
```

## 9. 当前环境边界

当前执行环境无法提供可信的 Windows WebGPU 实机视觉确认。数据、算法、语法、模块协议、启动器和 HTTP 路由已通过自动测试。

仍需在用户的 Windows Chrome 或 Edge 中检查：

```text
三维比例滑块是否具有连续视觉反馈
锁骨控制点是否完全隐藏
肩关节球是否唯一
修改比例后骨架和参考表皮的差异提示是否清楚
四个浏览器工作台的 SharedWorker 同步
当前实验表皮在极端姿势下的肩部和腋下质量
```
