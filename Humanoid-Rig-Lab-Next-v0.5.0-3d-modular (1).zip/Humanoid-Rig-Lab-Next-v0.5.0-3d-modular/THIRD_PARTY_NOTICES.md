# Third-party notices

The integrated V8.4 three-dimensional proportion viewport includes Three.js integration code and a sample SMPL-related surface asset. Review:

- `legacy/v8/THIRD_PARTY_NOTICES.md`
- `legacy/v8/assets/smpl/ATTRIBUTION.md`

Three.js is distributed under the MIT License. The included sample surface keeps the attribution and reuse conditions recorded in its asset folder. The package does not include the licensed full SMPL parametric model, official learned skin weights, joint regressor, or pose-corrective blend shapes.

Every production model, texture, motion file and training-derived asset must receive a separate license review before publication.
