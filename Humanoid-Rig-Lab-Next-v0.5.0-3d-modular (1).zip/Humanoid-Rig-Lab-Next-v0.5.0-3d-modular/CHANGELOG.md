# Changelog

## 0.5.0 collaboration completion

- Finished the primary three-dimensional proportion workspace and exact BodyProfile preview.
- Separated all four module source directories and module revisions.
- Added four-chat ownership rules, startup prompts and handoff templates.
- Added GitHub branch preparation for integration and four work branches.
- Added manual GitHub review and Pull Request workflow.
- Added module starter kits for work without Codex.


## 0.4.0 · 2026-08-18

- 删除程序化人体、隐藏选择人体和黄色表面代理。
- 精细 SMPL 网格同时承担显示、Raycaster 拾取和姿势变形。
- 点击人物三角形后通过顶点权重解析主导关节。
- A 绑定姿势直接恢复原始顶点和法线。
- 蒙皮变形改为人体区域隔离的四关节双四元数方法。
- 增加三角形邻接权重平滑、A 姿势手部下肢候选保护和 T 姿势网格拉伸质量门槛。
- 骨架重新拟合当前示例人体的肩、腕、髋、膝、踝和足部。
- ProjectState 升级为 schemaVersion 4。
- 骨架 JSON 升级为 schemaVersion 5。
- 旧 auto、base 和 fallbackAsset 表皮数据自动迁移到唯一精细表皮。
- 内置编辑器升级到 V8.3。

## 0.3.0 · 2026-08-18

### 统一人物视口

- 将 V8.2 实际三维人物视口嵌入比例、蒙皮、动作、动画和综合预览工作台。
- 轻量 Canvas 人偶改为故障回退，不再作为模块默认视觉结果。
- 比例、蒙皮、动画和综合预览使用只读人物视口。
- 动作与物理工作台可以直接拖动表皮、关节或骨杆。
- 增加母平台与 V8.2 的同源消息桥接。
- 增加 V8 姿势载荷跨窗口同步。

### 单层表皮

- 精细表皮接管后，将基础程序化人体 Group 从 Three.js 渲染场景移除。
- 基础人体继续作为脱离场景的 Raycaster 拾取代理。
- 不再依赖 `colorWrite`、透明度或深度写入隐藏基础人体。
- 增加 `attachedToScene` 诊断字段。
- 增加渲染场景级来源互斥测试。
- 修复 WebGPU 实机中黄色头部、颈部和肢体仍可能残留的问题。

### 数据与协作

- ProjectState 升级为 schemaVersion 3。
- PoseSnapshot 增加 `v8Payload`，保存完整三维姿势数据。
- 模块包和集成快照使用 schemaVersion 3。
- 保留 schemaVersion 1 和 2 项目迁移。

### 验证

- 增加统一 iframe 视口桥接静态测试。
- 增加脱离场景的隐藏拾取代理测试。
- 增加 V8 姿势载荷模块 Patch 合并测试。

## 0.2.0 · 2026-08-18

### 人物表皮

- 修复基础程序化表皮与精细 SMPL 表皮同时显示的问题。
- 建立单一可见表皮规则，任意时刻最多显示一层人体表面。
- 默认采用自动精细优先模式，精细表皮完成后自动隐藏基础表皮。
- 基础表皮在隐藏后保留为不可见拾取壳，继续支持直接触碰身体部位。
- 增加自动、精细 SMPL、基础程序化三种表皮来源选择。
- 增加 `singleVisibleSurface`、`activeSource` 与来源诊断信息。
- 将内置三维实验编辑器升级为 V8.1。

### 四模块协作

- 将比例、蒙皮、动作、动画和综合预览拆分到独立模块目录。
- 将 ProjectState 升级为 schemaVersion 2。
- 为五个模块建立独立 `moduleRevision` 与 `moduleUpdatedAt`。
- 使用模块级 Patch 代替四窗口整份状态互相覆盖。
- 支持多个模块在接近同时修改时合并各自数据。
- 增加过期 Patch 拒绝和旧 schemaVersion 1 项目迁移。
- 增加模块更新包导入与导出。
- 蒙皮工作台增加表皮来源、显示模式、透明度和重建状态控制。
- 动作工作台增加全身联动、阻尼、固定脚与人体限制共享参数。
- 动画工作台增加将当前动作保存为关键帧草案。

### 验证

- 增加模块并发 Patch 自动测试。
- 增加 V8.1 单一表皮集成测试。
- 增加基础表皮隐藏后仍可拾取的测试。
- 完成首页、SharedWorker 和 GLB 本地 HTTP 路由及 MIME 类型检查。

## 0.1.1

- 修复 `start.bat` 依赖中文文件名造成的 Windows 启动失败。
- 新增纯 ASCII 启动入口 `START_HERE.cmd`。
- 新增 `launcher.ps1`，自动选择 Node.js 或 Windows PowerShell 服务器。
- 新增无 Node.js 启动回退、端口检测、启动日志和诊断文件。

## 0.1.0 · 2026-08-18

- 建立统一项目总控网站。
- 建立骨骼比例、人物蒙皮、动作与物理、动画系统四个工作台。
- 建立综合人物预览和 V8 实验编辑器入口。
- 建立 SharedWorker、BroadcastChannel 与本地持久化协作链路。
- 建立模块状态、版本、测试、阻塞和审查记录。
- 建立项目 JSON、模块 JSON 与 ReviewBundle 导出。
- 建立 GitHub Actions 验证和 GitHub Pages 发布工作流。
- 建立 Windows 本地启动、测试与 GitHub 同步脚本。
