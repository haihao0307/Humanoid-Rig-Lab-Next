KAOPU Leather R02
BaseColor: sRGB. All other maps: linear. Normal +Y (OpenGL).
Tile width: 96 mm. UV 1 = 0.096 m.
Height in mm: uint16/65535 * recipe.parameters.depth.
Craft geometry is NOT baked into these tile maps. No leather dynamics.
Original procedural code, no Adobe assets. Visual fidelity not certified one-to-one.